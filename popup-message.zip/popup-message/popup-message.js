/*!
=========================================
 PREMIUM SUCCESS / ERROR POPUP PLUGIN
=========================================

USAGE:

showSuccessPopup('Title', 'Message', 'top-right', 3000);

showErrorPopup('Title', 'Message', 'center', 5000);

POSITION:
top-right | top-left | bottom-right | bottom-left | top-center | bottom-center | center

DURATION:
in ms (optional)

=========================================
*/

(function ($) {

    // =========================
    // STYLE INJECT (YOUR CSS)
    // =========================
    const style = `
    <style>

    .premium-success-message,
    .premium-error-message {
        position: fixed;
        z-index: 999999;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        background: #ffffff;
        padding: 25px 25px;
        border-radius: 6px;
        text-align: center;
        border: none;
        max-width: 400px;
        min-width: 280px;
        display: none;
    }
        
    .premium-success-message,
    .premium-error-message {
        border-top: 6px solid transparent;
        position: fixed;
        z-index: 999999;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        background: #ffffff;
        padding: 25px 25px;
        border-radius: 6px;
        text-align: center;
        border: none;
        max-width: 400px;
        min-width: 280px;
        display: none;
    }

    .premium-success-message{
        border-top: 6px solid #10b981;
    }

    .premium-error-message {
        border-top: 6px solid #fa4949;
    }

    .premium-popup-close {
        position: absolute;
        top: -6px;
        right: -1px;
        border: none;
        background: #fc5b5b;
        width: 25px;
        height: 25px;
        border-radius: 0 6px 0px 0px;
        cursor: pointer;
        transition: all .3s ease;
        color: #ffffff;
        font-size: 10px;
    }

    .premium-popup-close:hover {
        border-radius: 6px 0px 0px 0px;
        transform: rotate(90deg);
        background: #fa4949;
        color: #fff;
    }

    .success-icon, .error-icon {
        width: 60px;
        height: 60px;
        margin: 0 auto 15px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 35px;
    }

    .success-icon {
        background: linear-gradient(135deg, #2563eb, #4f46e5);
    }

    .error-icon {
        background: linear-gradient(135deg, #f87171, #fca5a5);
    }

    .premium-success-message h3,
    .premium-error-message h3 {
        font-size: 18px;
        font-weight: 700;
        color: #111827;
        margin-bottom: 10px;
    }

    .premium-success-message p,
    .premium-error-message p {
        font-size: 14px;
        line-height: 1.5;
        color: #6b7280;
        margin-bottom: 10px;
    }

    </style>
    `;

    $('head').append(style);

    // =========================
    // CREATE POPUP HTML
    // =========================
    const html = `
        <div id="premiumSuccess" class="premium-success-message">
            <div class="success-icon"><i class="fa-solid fa-circle-check"></i></div>
            <h3 class="title"></h3>
            <p class="message"></p>
            <button class="premium-popup-close">✕</button>
        </div>

        <div id="premiumError" class="premium-error-message">
            <div class="error-icon"><i class="fa-solid fa-circle-xmark"></i></div>
            <h3 class="title"></h3>
            <p class="message"></p>
            <button class="premium-popup-close">✕</button>
        </div>
    `;

    $('body').append(html);

    // =========================
    // POSITION FUNCTION
    // =========================
    function setPosition(el, position) {

        const base = {
            top: '20px',
            bottom: '20px',
            left: '20px',
            right: '20px',
            transform: 'none'
        };

        switch (position) {

            case 'top-right':
                el.css({ top: '20px', right: '20px', left: 'auto', bottom: 'auto' });
                break;

            case 'top-left':
                el.css({ top: '20px', left: '20px', right: 'auto', bottom: 'auto' });
                break;

            case 'bottom-right':
                el.css({ bottom: '20px', right: '20px', top: 'auto', left: 'auto' });
                break;

            case 'bottom-left':
                el.css({ bottom: '20px', left: '20px', top: 'auto', right: 'auto' });
                break;

            case 'top-center':
                el.css({
                    top: '20px',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    right: 'auto',
                    bottom: 'auto'
                });
                break;

            case 'bottom-center':
                el.css({
                    bottom: '20px',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    right: 'auto',
                    top: 'auto'
                });
                break;

            case 'center':
            default:
                el.css({
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)'
                });
                break;
        }
    }

    // =========================
    // CLOSE BUTTON
    // =========================
    $(document).on('click', '.premium-popup-close', function () {
        $(this).parent().fadeOut(200);
    });

    // =========================
    // SUCCESS POPUP
    // =========================
    window.showSuccessPopup = function (title, message, position = 'center', duration = null) {

        let el = $('#premiumSuccess');

        el.find('.title').text(title);
        el.find('.message').text(message);

        setPosition(el, position);

        el.fadeIn(200);

        if (duration) {
            setTimeout(() => {
                el.fadeOut(200);
            }, duration);
        }
    };

    // =========================
    // ERROR POPUP
    // =========================
    window.showErrorPopup = function (title, message, position = 'center', duration = null) {

        let el = $('#premiumError');

        el.find('.title').text(title);
        el.find('.message').text(message);

        setPosition(el, position);

        el.fadeIn(200);

        if (duration) {
            setTimeout(() => {
                el.fadeOut(200);
            }, duration);
        }
    };

})(jQuery);