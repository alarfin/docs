<?php



Auth::routes(['register' => false, 'reset' => false]);

Route::get('/', function () {
    return redirect()->route('login');
});

Route::middleware(['auth'])->group(function () {
    Route::get('section-login', 'SectionController@sectionLogin')->name('section_login');
    Route::get('go-to-dashboard/{type}', 'SectionController@goToDashboard')->name('go_to_dashboard');
    Route::get('dashboard', 'DashboardController@index')->name('dashboard');

    // Setting
    Route::get('setting/add', 'SettingController@add')->name('setting_add');
    Route::post('setting/add', 'SettingController@store');

    // Section
    Route::get('section', 'SectionController@index')->name('section');
    Route::get('section/add', 'SectionController@add')->name('section.add');
    Route::post('section/add', 'SectionController@addPost');
    Route::get('section/edit/{section}', 'SectionController@edit')->name('section.edit');
    Route::post('section/edit/{section}', 'SectionController@editPost');

    // Company Branch
    Route::get('company-branches', 'CompanyBranchController@index')->name('company_branches');
    Route::get('company-branch-datatable', 'CompanyBranchController@companyBranchDatatable')->name('company_branch_datatable');
    Route::get('company-branch/add', 'CompanyBranchController@add')->name('company_branch_add');
    Route::post('company-branch/add', 'CompanyBranchController@addPost');
    Route::get('company-branch/edit/{company_branch}', 'CompanyBranchController@edit')->name('company_branch_edit');
    Route::post('company-branch/edit/{company_branch}', 'CompanyBranchController@editPost');
    Route::get('company-branch/delete/{company_branch}', 'CompanyBranchController@delete')->name('company_branch_delete');

    // Bank
    Route::get('bank', 'BankController@index')->name('bank')->middleware('permission:bank');
    Route::get('bank/add', 'BankController@add')->name('bank_add')->middleware('permission:bank');
    Route::post('bank/add', 'BankController@addPost')->middleware('permission:bank');
    Route::get('bank/edit/{bank}', 'BankController@edit')->name('bank_edit')->middleware('permission:bank');
    Route::post('bank/edit/{bank}', 'BankController@editPost')->middleware('permission:bank');
    Route::get('bank/delete/{bank}', 'BankController@delete')->name('bank_delete');

    // Supplier
    Route::get('supplier', 'SupplierController@index')->name('supplier');
    Route::get('supplier-datatable', 'SupplierController@supplierDatatable')->name('supplier_datatable');
    Route::get('supplier/add', 'SupplierController@add')->name('supplier_add');
    Route::post('supplier/add', 'SupplierController@store');
    Route::get('supplier/edit/{supplier}', 'SupplierController@edit')->name('supplier_edit');
    Route::post('supplier/edit/{supplier}', 'SupplierController@update');
    Route::get('supplier/delete/{supplier}', 'supplierController@delete')->name('supplier_delete');

    /*********************
     * Human Resouce (HR)
     */

    // Desingation
    Route::get('designations', 'DesignationController@index')->name('designations');
    Route::get('designation-datatable', 'DesignationController@designationDatatable')->name('designation_datatable');
    Route::get('designation/add', 'DesignationController@add')->name('designation_add');
    Route::post('designation/add', 'DesignationController@store');
    Route::get('designation/edit/{designation}', 'DesignationController@edit')->name('designation_edit');
    Route::post('designation/edit/{designation}', 'DesignationController@update');
    Route::get('designation/delete/{designation}', 'DesignationController@delete')->name('designation_delete');

    // Employee
    Route::get('employees', 'EmployeeController@index')->name('employees');
    Route::get('employee-datatable', 'EmployeeController@employeeDatatable')->name('employee_datatable');
    Route::get('employee/add', 'EmployeeController@add')->name('employee_add');
    Route::post('employee/add', 'EmployeeController@store');
    Route::get('employee/edit/{employee}', 'EmployeeController@edit')->name('employee_edit');
    Route::post('employee/edit/{employee}', 'EmployeeController@update');
    Route::get('employee/details/{employee}', 'EmployeeController@details')->name('employee_details');
    Route::get('employee/delete/{employee}', 'EmployeeController@delete')->name('employee_delete');

    // Employee Attendance
    Route::get('attendances', 'AttendanceController@index')->name('attendances');
    Route::get('attendance-datatable', 'AttendanceController@attendanceDatatable')->name('attendance_datatable');
    Route::get('attendance/add', 'AttendanceController@add')->name('attendance_add');
    Route::post('attendance/add', 'AttendanceController@store');
    Route::get('attendance/edit/{attendance}', 'AttendanceController@edit')->name('attendance_edit');
    Route::post('attendance/edit/{attendance}', 'AttendanceController@update');
    Route::get('attendance/details/{attendance}', 'AttendanceController@details')->name('attendance_details');
    Route::get('attendance/delete/{attendance}', 'AttendanceController@delete')->name('attendance_delete');

    // Salary Process
    Route::get('salary-processes', 'SalaryProcessController@index')->name('salary_processes');
    Route::get('salary-process-datatable', 'SalaryProcessController@salaryProcessDatatable')->name('salary_process_datatable');
    Route::get('salary-process/add', 'SalaryProcessController@add')->name('salary_process_add');
    Route::post('salary-process/add', 'SalaryProcessController@store');
    Route::get('salary-process/edit/{salary_process}', 'SalaryProcessController@edit')->name('salary_process_edit');
    Route::post('salary-process/edit/{salary_process}', 'SalaryProcessController@update');
    Route::get('salary-process/details/{salary_process}', 'SalaryProcessController@details')->name('salary_process_details');
    Route::get('salary-process/delete/{salary_process}', 'SalaryProcessController@delete')->name('salary_process_delete');


    // Customer
    Route::get('customer', 'CustomerController@index')->name('customer')->middleware('permission:customer');
    Route::get('customer/add', 'CustomerController@add')->name('customer_add')->middleware('permission:customer');
    Route::post('customer/add', 'CustomerController@addPost')->middleware('permission:customer');
    Route::get('customer/edit/{customer}', 'CustomerController@edit')->name('customer_edit')->middleware('permission:customer');
    Route::post('customer/edit/{customer}', 'CustomerController@editPost')->middleware('permission:customer');
    Route::get('customer/datatable', 'CustomerController@customerDatatable')->name('customer_datatable')->middleware('permission:customer');
    Route::get('customer/delete/{customer}', 'customerController@delete')->name('customer_delete');

    Route::post('store-new-customer', 'customerController@storeCustomer')->name('store_new_customer');


    // Product Unit
    Route::get('product-units', 'ProductUnitController@index')->name('product_units');
    Route::get('product-unit-datatble', 'ProductUnitController@productDatatable')->name('product_unit_datatable');
    Route::get('product-unit/add', 'ProductUnitController@add')->name('product_unit_add');
    Route::post('product-unit/add', 'ProductUnitController@store');
    Route::get('product-unit/edit/{product_unit}', 'ProductUnitController@edit')->name('product_unit_edit');
    Route::post('product-unit/edit/{product_unit}', 'ProductUnitController@update');
    Route::get('product-unit/delete/{product_unit}', 'ProductUnitController@delete')->name('product_unit_delete');

    // Product Category
    Route::get('product-categories', 'ProductCategoryController@index')->name('product_categories');
    Route::get('product-category-datatble', 'ProductCategoryController@productDatatable')->name('product_category_datatable');
    Route::get('product-category/add', 'ProductCategoryController@add')->name('product_category_add');
    Route::post('product-category/add', 'ProductCategoryController@store');
    Route::get('product-category/edit/{product_category}', 'ProductCategoryController@edit')->name('product_category_edit');
    Route::post('product-category/edit/{product_category}', 'ProductCategoryController@update');
    Route::get('product-category/delete/{product_category}', 'ProductCategoryController@delete')->name('product_category_delete');

    // Product
    Route::get('products', 'ProductController@index')->name('products');
    Route::get('product-datatble', 'ProductController@productDatatable')->name('product_datatable');
    Route::get('product/add', 'ProductController@add')->name('product_add');
    Route::post('product/add', 'ProductController@store');
    Route::get('product/edit/{product}', 'ProductController@edit')->name('product_edit');
    Route::post('product/edit/{product}', 'ProductController@update');
    Route::get('product/delete/{product}', 'ProductController@delete')->name('product_delete');
    Route::get('product/barcode-print', 'ProductController@barcodePrint')->name('product_barcode_print');
    Route::get('product/qrcode-print', 'ProductController@qrcodePrint')->name('product_qrcode_print');

    // Damage Product
    Route::get('product-damages', 'ProductDamageController@productDamages')->name('product_damages');
    Route::get('product-damage-datatable', 'ProductDamageController@productDamageDatatable')->name('product_damage_datatable');
    Route::get('product-damage-create', 'ProductDamageController@productDamageCreate')->name('product_damage_create');
    Route::post('product-damage-create', 'ProductDamageController@productDamageStore');
    Route::get('product-damage-delete/{inventory_log}', 'ProductDamageController@productDamageDelete')->name('product_damage_delete');

    // Inventory
    Route::get('inventory', 'InventoryController@inventory')->name('inventory');
    Route::get('inventory-datatable', 'InventoryController@inventoryDatatable')->name('inventory_datatable');
    Route::get('inventory-details', 'InventoryController@inventoryDetails')->name('inventory_details');
    Route::get('inventory-details-datatable', 'InventoryController@inventoryDetailsDatatable')->name('inventory_details_datatable');


    // Purchase Order
    Route::get('purchase-orders', 'PurchaseController@purchaseOrders')->name('purchase_orders');
    Route::get('purchase-order-datatable', 'PurchaseController@purchaseOrderDatatable')->name('purchase_order_datatable');
    Route::get('purchase-order-create', 'PurchaseController@purchaseOrderCreate')->name('purchase_order_create');
    Route::post('purchase-order-create', 'PurchaseController@purchaseOrderStore');
    Route::get('purchase-order-edit/{purchase_order}', 'PurchaseController@purchaseOrderEdit')->name('purchase_order_edit');
    Route::post('purchase-order-edit/{purchase_order}', 'PurchaseController@purchaseOrderUpdate');
    Route::get('purchase-order-details/{purchase_order}', 'PurchaseController@purchaseOrderDetails')->name('purchase_order_details');
    Route::get('purchase-order-print/{purchase_order}', 'PurchaseController@purchaseOrderPrint')->name('purchase_order_print');
    Route::post('purchase-order-payment', 'PurchaseController@purchaseOrderPayment')->name('purchase_order_payment');

    // Purchase Return
    Route::get('purchase-product-return', 'ReturnController@purchaseReturn')->name('purchase_return');
    Route::post('purchase-product-return', 'ReturnController@purchaseReturnStore');


    // Sale Order
    Route::get('sale-orders', 'SaleController@saleOrders')->name('sale_orders');
    Route::get('sale-order-datatable', 'SaleController@saleOrderDatatable')->name('sale_order_datatable');
    Route::get('sale-order-create', 'SaleController@saleOrderCreate')->name('sale_order_create');
    Route::post('sale-order-create', 'SaleController@saleOrderStore');
    Route::get('sale-order-delete/{sale_order}', 'SaleController@saleOrderDelete')->name('sale_order_delete');
    Route::get('sale-order-details/{sale_order}', 'SaleController@saleOrderDetails')->name('sale_order_details');
    Route::get('sale-order-print/{sale_order}', 'SaleController@saleOrderPrint')->name('sale_order_print');
    Route::post('sale-order-payment', 'SaleController@saleOrderPayment')->name('sale_order_payment');

    // Sale Return
    Route::get('sale-product-return', 'ReturnController@saleReturn')->name('sale_return');
    Route::post('sale-product-return', 'ReturnController@saleReturnStore');

    /******************
     *  Online Information
     */

    // Online Category
    Route::get('online-categories', 'OnlineCategoryController@index')->name('online_categories');
    Route::get('online-categories-datatable', 'OnlineCategoryController@onlineCategoryDatatable')->name('online_categories_datatable');
    Route::get('online-category/add', 'OnlineCategoryController@add')->name('online_category_add');
    Route::post('online-category/add', 'OnlineCategoryController@store');
    Route::get('online-category/edit/{online_category}', 'OnlineCategoryController@edit')->name('online_category_edit');
    Route::post('online-category/edit/{online_category}', 'OnlineCategoryController@update');
    Route::get('online-category/delete/{online_category}', 'OnlineCategoryController@delete')->name('online_category_delete');

    // Online information
    Route::get('online-informations', 'OnlineInformationController@index')->name('online_informations');
    Route::get('online-informations-datatable', 'OnlineInformationController@onlineInformationDatatable')->name('online_informations_datatable');
    Route::get('online-information/add', 'OnlineInformationController@add')->name('online_information_add');
    Route::post('online-information/add', 'OnlineInformationController@store');
    Route::get('online-information/details/{online_information}', 'OnlineInformationController@details')->name('online_information_details');
    Route::get('online-information/edit/{online_information}', 'OnlineInformationController@edit')->name('online_information_edit');
    Route::post('online-information/edit/{online_information}', 'OnlineInformationController@update');
    Route::get('online-information/delete/{online_information}', 'OnlineInformationController@delete')->name('online_information_delete');

    Route::post('online-information-payment', 'OnlineInformationController@payment')->name('online_information_payment');


    // Account Head
    Route::get('account-heads', 'AccountHeadController@index')->name('account_heads');
    Route::get('account-heads-datatable', 'AccountHeadController@accountHeadsDatatable')->name('account_heads_datatable');
    Route::get('account-head/add', 'AccountHeadController@add')->name('account_head_add');
    Route::post('account-head/add', 'AccountHeadController@store');
    Route::get('account-head/edit/{account_head}', 'AccountHeadController@edit')->name('account_head_edit');
    Route::post('account-head/edit/{account_head}', 'AccountHeadController@update');
    Route::get('account-head/delete/{account_head}', 'AccountHeadController@delete')->name('account_head_delete');

    // Account
    Route::get('accounts', 'AccountController@index')->name('accounts');
    Route::get('accounts-datatable', 'AccountController@accountsDatatable')->name('accounts_datatable');
    Route::get('account/add', 'AccountController@add')->name('account_add');
    Route::post('account/add', 'AccountController@store');
    Route::get('account/edit/{account}', 'AccountController@edit')->name('account_edit');
    Route::post('account/edit/{account}', 'AccountController@update');
    Route::get('account/delete/{account}', 'AccountController@delete')->name('account_delete');


    // Debit voucher
    Route::get('debit-transactions', 'AccountTransactionController@debitTransactions')->name('debit_transactions');
    Route::get('debit-transaction-datatable', 'AccountTransactionController@debitTransactionDatatable')->name('debit_transaction_datatable');
    Route::get('employee-debit-transaction/add', 'AccountTransactionController@employeeDebitTransactionAdd')->name('employee_debit_transaction_add');
    Route::get('supplier-debit-transaction/add', 'AccountTransactionController@supplierDebitTransactionAdd')->name('supplier_debit_transaction_add');
    Route::get('debit-transaction/add', 'AccountTransactionController@debitTransactionAdd')->name('debit_transaction_add');
    Route::post('debit-transaction/add', 'AccountTransactionController@debitTransactionStore');
    Route::get('debit-transaction/details/{transaction}', 'AccountTransactionController@debitTransactionDetails')->name('debit_transaction_details');

    // Credit voucher
    Route::get('credit-transactions', 'AccountTransactionController@creditTransactions')->name('credit_transactions');
    Route::get('credit-transaction-datatable', 'AccountTransactionController@creditTransactionDatatable')->name('credit_transaction_datatable');
    Route::get('employee-credit-transaction/add', 'AccountTransactionController@employeeCreditTransactionAdd')->name('employee_credit_transaction_add');
    Route::get('supplier-credit-transaction/add', 'AccountTransactionController@supplierCreditTransactionAdd')->name('supplier_credit_transaction_add');
    Route::get('credit-transaction/add', 'AccountTransactionController@creditTransactionAdd')->name('credit_transaction_add');
    Route::post('credit-transaction/add', 'AccountTransactionController@creditTransactionStore');
    Route::get('credit-transaction/details/{transaction}', 'AccountTransactionController@creditTransactionDetails')->name('credit_transaction_details');

    // Balance Transfer
    Route::get('balance-transfers', 'BalanceTransferController@balanceTransfers')->name('balance_transfers');
    Route::get('balance-transfer-datatable', 'BalanceTransferController@balanceTransferDatatable')->name('balance_transfer_datatable');
    Route::get('balance-transfer/add', 'BalanceTransferController@balanceTransferAdd')->name('balance_transfer_add');
    Route::post('balance-transfer/add', 'BalanceTransferController@balanceTransferStore');
    Route::get('balance-transfer/details/{balance_transfer}', 'BalanceTransferController@balanceTransferDetails')->name('balance_transfer_details');

    // Adjustment voucher
    Route::get('account-adjustments', 'AccountAdjustmentController@accountAdjustments')->name('account_adjustments');
    Route::get('account-adjustment-datatable', 'AccountAdjustmentController@accountAdjustmentDatatable')->name('account_adjustment_datatable');
    Route::get('account-adjustment/add', 'AccountAdjustmentController@accountAdjustmentAdd')->name('account_adjustment_add');
    Route::post('account-adjustment/add', 'AccountAdjustmentController@accountAdjustmentStore');
    Route::get('account-adjustment/details/{transaction_log}', 'AccountAdjustmentController@accountAdjustmentDetails')->name('account_adjustment_details');

    // Opening Balance
    Route::get('opening-balances', 'OpeningBalanceController@openingBalances')->name('opening_balances');
    Route::get('opening-balance-datatable', 'OpeningBalanceController@openingBalanceDatatable')->name('opening_balance_datatable');
    Route::get('employee-opening-balance/add', 'OpeningBalanceController@employeeOpeningBalanceAdd')->name('employee_opening_balance_add');
    Route::get('customer-opening-balance/add', 'OpeningBalanceController@customerOpeningBalanceAdd')->name('customer_opening_balance_add');
    Route::get('supplier-opening-balance/add', 'OpeningBalanceController@supplierOpeningBalanceAdd')->name('supplier_opening_balance_add');
    Route::get('bank-opening-balance/add', 'OpeningBalanceController@bankOpeningBalanceAdd')->name('bank_opening_balance_add');
    Route::get('opening-balance/add', 'OpeningBalanceController@openingBalanceAdd')->name('opening_balance_add');
    Route::post('opening-balance/add', 'OpeningBalanceController@openingBalanceStore');
    Route::get('opening-balance/details/{transaction_log}', 'OpeningBalanceController@openingBalanceDetails')->name('opening_balance_details');

    Route::get('user', 'UserController@index')->name('user_all');
    Route::get('user-datatable', 'UserController@userDatatable')->name('user_datatable');
    Route::get('user/add', 'UserController@add')->name('user_add');
    Route::post('user/add', 'UserController@addPost');
    Route::get('user/edit/{user}', 'UserController@edit')->name('user_edit');
    Route::post('user/edit/{user}', 'UserController@editPost');

    // Report
    Route::group(['as' => 'report_'], function () {
        Route::get('chart-of-accounts', 'ReportController@chartOfAccounts')->name('chart_of_accounts');
        Route::get('trial-balance', 'ReportController@trialBalance')->name('trial_balance');
        Route::get('salary-sheet', 'ReportController@salarySheet')->name('salary_sheet');
        Route::get('supplier-report', 'ReportController@supplierReport')->name('supplier');
        Route::get('customer-report', 'ReportController@customerReport')->name('customer');
        Route::get('ledger', 'ReportController@ledgerReport')->name('ledger');
        Route::get('cash-bank-statements', 'ReportController@cashBankStatement')->name('cash_bank_statement');
        Route::get('purchase-report', 'ReportController@purchaseReport')->name('purchase');
        Route::get('purchase-product-report', 'ReportController@purchaseProductReport')->name('purchase_product');
        Route::get('purchase-product-return-report', 'ReportController@purchaseProductReturnReport')->name('purchase_product_return');
        Route::get('sale-report', 'ReportController@saleReport')->name('sale');
        Route::get('sale-product-report', 'ReportController@saleProductReport')->name('sale_product');
        Route::get('sale-product-return-report', 'ReportController@saleProductReturnReport')->name('sale_product_return');
        Route::get('stock', 'ReportController@stockReport')->name('stock');
        Route::get('balance-summary', 'ReportController@balanceSummary')->name('balance_summary');
    });

    Route::get('report/sale', 'ReportController@sale')->name('report.sale')->middleware('permission:sale_report');
    Route::get('report/balance-sheet', 'ReportController@balanceSheet')->name('report.balance_sheet')->middleware('permission:balance_sheet');
    Route::get('report/profit-and-loss', 'ReportController@profitAndLoss')->name('report.profit_and_loss')->middleware('permission:profit_and_loss');
    Route::get('report/ledger', 'ReportController@ledger')->name('report.ledger')->middleware('permission:ledger');
    Route::get('report/transaction', 'ReportController@transaction')->name('report.transaction')->middleware('permission:transaction_report');

    // Common
    Route::get('order-details', 'CommonController@orderDetails')->name('get_order_details');
    Route::get('get-suppliers', 'CommonController@getsuppliers')->name('get_supplier');
    Route::get('get_customers', 'CommonController@getCustomers')->name('get_customers');
    Route::get('get-products-by-code', 'CommonController@getProductsByCode')->name('get_products_by_code');
    Route::get('get-sale-products-by-code', 'CommonController@getSaleProductsByCode')->name('get_sale_products_by_code');
    Route::get('get-products', 'CommonController@getProducts')->name('get_products');
    Route::get('get-product-details', 'CommonController@getProductDetails')->name('get_product_details');
    Route::get('get-employees', 'CommonController@getEmployees')->name('get_employees');
    Route::get('get-branch-employees', 'CommonController@getBranchEmployees')->name('get_branch_employees');
    Route::get('get-salary-month', 'CommonController@getSalaryMonth')->name('get_salary_month');
    Route::get('get-month-for-salary-sheet', 'CommonController@getMonthSalarySheet')->name('get_month_salary_sheet');
    Route::get('get-section-branch', 'CommonController@getSectionBranch')->name('get_section_branch');
});


Route::get('/cache-clear', function () {
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('config:cache');
    Artisan::call('view:clear');
    return "Cleared!";
});
