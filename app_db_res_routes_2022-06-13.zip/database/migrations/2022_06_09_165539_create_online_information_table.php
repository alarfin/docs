<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOnlineInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('online_information', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('client_id')->nullable();
            $table->bigInteger('section_id')->nullable();
            $table->bigInteger('company_branch_id')->nullable();
            $table->bigInteger('online_category_id')->nullable();
            $table->bigInteger('customer_id')->nullable();
            $table->string('serial_no')->nullable();
            $table->date('date')->nullable();
            $table->string('name', 255)->nullable();
            $table->string('mobile_no', 255)->nullable();
            $table->string('nid_no', 255)->nullable();
            $table->string('user', 255)->nullable();
            $table->string('pin', 255)->nullable();
            $table->string('password', 255)->nullable();
            $table->tinyInteger('payment_method')->nullable()->comment('1=Cash In Hand, 2=Bank');
            $table->integer('bank_id')->nullable();
            $table->double('total', 20, 2)->nullable()->default(0);
            $table->double('paid', 20, 2)->nullable()->default(0);
            $table->double('due', 20, 2)->nullable()->default(0);
            $table->text('note')->nullable();
            $table->bigInteger('user_id')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('online_information');
    }
}
