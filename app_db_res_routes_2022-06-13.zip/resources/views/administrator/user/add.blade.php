@extends('layouts.app')
@section('administrator', 'active menu-open')
@section('user_add', 'active')
@section('style')
    <link rel="stylesheet" href="{{ asset('themes/backend/bower_components/select2/dist/css/select2.min.css') }}">
    <!-- iCheck -->
    <link rel="stylesheet" href="{{ asset('themes/backend/plugins/iCheck/square/blue.css') }}">
@endsection

@section('title')
    User Add
@endsection

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">User Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" action="{{ route('user_add') }}">
                    @csrf

                    <div class="box-body">

                        <div class="form-group">
                            <label class="col-sm-2 control-label"> Section *</label>

                            <div class="col-sm-10">
                                <select name="section_ids[]" id="section_ids" class="form-control select2" multiple
                                    required>
                                    {{-- <option value="">Select Section </option> --}}
                                    @foreach ($sections as $section)
                                        <option value="{{ $section->id }}"
                                            @if (in_array($section->id, old('section_ids', []))) selected @endif>
                                            {{ $section->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                            <label class="col-sm-2 control-label">Name *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Name" name="name"
                                    value="{{ old('name') }}">

                                @error('name')
                                    <span class="help-block">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">
                            <label class="col-sm-2 control-label">Email *</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Email" name="email"
                                    value="{{ old('email') }}">

                                @error('email')
                                    <span class="help-block">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group {{ $errors->has('mobile_no') ? 'has-error' : '' }}">
                            <label class="col-sm-2 control-label"> Mobile no </label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter mobile_no" name="mobile_no"
                                    value="{{ old('mobile_no') }}">

                                @error('mobile_no')
                                    <span class="help-block">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group {{ $errors->has('password') ? 'has-error' : '' }}">
                            <label class="col-sm-2 control-label">Password *</label>

                            <div class="col-sm-10">
                                <input type="password" class="form-control" placeholder="Enter Password" name="password"
                                    autocomplete="new-password">

                                @error('password')
                                    <span class="help-block">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label">Confirm Password *</label>

                            <div class="col-sm-10">
                                <input type="password" class="form-control" placeholder="Enter Confirm Password"
                                    name="password_confirmation">
                            </div>
                        </div>

                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="{{ asset('themes/backend/bower_components/select2/dist/js/select2.full.min.js') }}"></script>
    <!-- iCheck -->
    <script src="{{ asset('themes/backend/plugins/iCheck/icheck.min.js') }}"></script>
    <script>
        $(function() {
            $('.select2').select2()
            $("#checkAll").click(function() {
                $('input:checkbox').not(this).prop('disabled', this.disabled);
                $('input:checkbox').not(this).prop('checked', this.checked);

                init();
            });

            // Administrator
            $('#administrator').click(function() {
                if ($(this).prop('checked')) {
                    $('#warehouse').attr("disabled", false);
                } else {
                    $('#warehouse').attr("disabled", true);
                }
            });

            // Bank & Account
            $('#bank_and_account').click(function() {
                if ($(this).prop('checked')) {
                    $('#bank').attr("disabled", false);
                    $('#branch').attr("disabled", false);
                    $('#account').attr("disabled", false);
                } else {
                    $('#bank').attr("disabled", true);
                    $('#branch').attr("disabled", true);
                    $('#account').attr("disabled", true);
                }
            });

            // Purchase
            $('#purchase').click(function() {
                if ($(this).prop('checked')) {
                    $('#supplier').attr("disabled", false);
                    $('#purchase_product').attr("disabled", false);
                    $('#purchase_order').attr("disabled", false);
                    $('#purchase_receipt').attr("disabled", false);
                    $('#purchase_inventory').attr("disabled", false);
                    $('#supplier_payment').attr("disabled", false);
                } else {
                    $('#supplier').attr("disabled", true);
                    $('#purchase_product').attr("disabled", true);
                    $('#purchase_order').attr("disabled", true);
                    $('#purchase_receipt').attr("disabled", true);
                    $('#purchase_inventory').attr("disabled", true);
                    $('#supplier_payment').attr("disabled", true);
                }
            });

            // Sale
            $('#sale').click(function() {
                if ($(this).prop('checked')) {
                    $('#customer').attr("disabled", false);
                    $('#sales_order').attr("disabled", false);
                    $('#sale_receipt').attr("disabled", false);
                    $('#product_sale_information').attr("disabled", false);
                    $('#customer_payment').attr("disabled", false);
                } else {
                    $('#customer').attr("disabled", true);
                    $('#sale_product').attr("disabled", true);
                    $('#sales_order').attr("disabled", true);
                    $('#sale_receipt').attr("disabled", true);
                    $('#product_sale_information').attr("disabled", true);
                    $('#customer_payment').attr("disabled", true);
                }
            });

            // Accounts
            $('#accounts').click(function() {
                if ($(this).prop('checked')) {
                    $('#account_head_type').attr("disabled", false);
                    $('#account_head_sub_type').attr("disabled", false);
                    $('#transaction').attr("disabled", false);
                    $('#balance_transfer').attr("disabled", false);
                } else {
                    $('#account_head_type').attr("disabled", true);
                    $('#account_head_sub_type').attr("disabled", true);
                    $('#transaction').attr("disabled", true);
                    $('#balance_transfer').attr("disabled", true);
                }
            });

            // Report
            $('#report').click(function() {
                if ($(this).prop('checked')) {
                    $('#purchase_report').attr("disabled", false);
                    $('#sale_report').attr("disabled", false);
                    $('#balance_sheet').attr("disabled", false);
                    $('#profit_and_loss').attr("disabled", false);
                    $('#ledger').attr("disabled", false);
                    $('#transaction_report').attr("disabled", false);
                } else {
                    $('#purchase_report').attr("disabled", true);
                    $('#sale_report').attr("disabled", true);
                    $('#balance_sheet').attr("disabled", true);
                    $('#profit_and_loss').attr("disabled", true);
                    $('#ledger').attr("disabled", true);
                    $('#transaction_report').attr("disabled", true);
                }
            });

            // User Management
            $('#user_management').click(function() {
                if ($(this).prop('checked')) {
                    $('#users').attr("disabled", false);
                } else {
                    $('#users').attr("disabled", true);
                }
            });

            init();
        });

        function init() {
            if (!$('#administrator').prop('checked')) {
                $('#warehouse').attr("disabled", true);
            }

            if (!$('#bank_and_account').prop('checked')) {
                $('#bank').attr("disabled", true);
                $('#branch').attr("disabled", true);
                $('#account').attr("disabled", true);
            }

            if (!$('#purchase').prop('checked')) {
                $('#supplier').attr("disabled", true);
                $('#purchase_product').attr("disabled", true);
                $('#purchase_order').attr("disabled", true);
                $('#purchase_receipt').attr("disabled", true);
                $('#purchase_inventory').attr("disabled", true);
                $('#supplier_payment').attr("disabled", true);
            }

            if (!$('#sale').prop('checked')) {
                $('#customer').attr("disabled", true);
                $('#sales_order').attr("disabled", true);
                $('#sale_receipt').attr("disabled", true);
                $('#product_sale_information').attr("disabled", true);
                $('#customer_payment').attr("disabled", true);
            }

            if (!$('#accounts').prop('checked')) {
                $('#account_head_type').attr("disabled", true);
                $('#account_head_sub_type').attr("disabled", true);
                $('#transaction').attr("disabled", true);
                $('#balance_transfer').attr("disabled", true);
            }

            if (!$('#report').prop('checked')) {
                $('#purchase_report').attr("disabled", true);
                $('#sale_report').attr("disabled", true);
                $('#balance_sheet').attr("disabled", true);
                $('#profit_and_loss').attr("disabled", true);
                $('#ledger').attr("disabled", true);
                $('#transaction_report').attr("disabled", true);
            }

            if (!$('#user_management').prop('checked')) {
                $('#users').attr("disabled", true);
            }
        }
    </script>
@endsection
