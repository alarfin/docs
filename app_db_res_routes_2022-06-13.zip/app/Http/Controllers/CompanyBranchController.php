<?php

namespace App\Http\Controllers;

use App\Models\CompanyBranch;
use App\Models\Section;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;

class CompanyBranchController extends Controller
{
    public function index()
    {
        return view('administrator.company_branch.all');
    }

    public function add()
    {
        $sections = Section::where('status',1)->get();
        return view('administrator.company_branch.add', compact('sections'));
    }

    public function addPost(Request $request)
    {
        $request->validate([
            'section_id' => 'required',
            'name' => 'required|string|max:255',
            'mobile_no' => 'required|string|max:255',
            'email' => 'nullable|email',
            'address' => 'nullable|string|max:255',
            'status' => 'required',
        ]);

        $company_branch = new CompanyBranch();
        $company_branch->client_id = Auth::user()->client_id;
        $company_branch->section_id = $request->section_id;
        $company_branch->name = $request->name;
        $company_branch->mobile_no = $request->mobile_no;
        $company_branch->email = $request->email;
        $company_branch->address = $request->address;
        $company_branch->status = $request->status;
        $company_branch->user_id = Auth::id();
        $company_branch->save();

        return redirect()->route('company_branches')->with('message', 'Company branch add successfully.');
    }

    public function edit(CompanyBranch $company_branch)
    {
        $this->clientCheck($company_branch);
        $sections = Section::where('status',1)->get();
        return view('administrator.company_branch.edit', compact('company_branch','sections'));
    }

    public function editPost(Request $request, CompanyBranch $company_branch)
    {
        $this->clientCheck($company_branch);
        $request->validate([
            'section_id' => 'required',
            'name' => 'required|string|max:255',
            'mobile_no' => 'required|string|max:255',
            'email' => 'nullable|email',
            'address' => 'nullable|string|max:255',
            'status' => 'required',
        ]);


        $company_branch->section_id = $request->section_id;
        $company_branch->name = $request->name;
        $company_branch->mobile_no = $request->mobile_no;
        $company_branch->email = $request->email;
        $company_branch->address = $request->address;
        $company_branch->status = $request->status;
        $company_branch->save();

        return redirect()->route('company_branches')->with('message', 'Company branch edit successfully.');
    }

    public function delete(CompanyBranch $company_branch)
    {
        $this->clientCheck($company_branch);
        $company_branch->update(['delete_user_id'=>Auth::id()]);
        $company_branch->delete();
        return redirect()->route('company_branches')->with('message', 'Company branch delete successfully.');
    }

    public function companyBranchDatatable()
    {
        $query = CompanyBranch::with('section')->where('client_id', Auth::user()->client_id);
        return DataTables::eloquent($query)
            ->addIndexColumn()
            ->addColumn('status', function (CompanyBranch $company_branch) {
                if ($company_branch->status == 1) {
                    return '<span class="label label-success"> Active </span>';
                } else {
                    return '<span class="label label-danger"> In Active </span>';
                }
            })
            ->addColumn('balance', function (CompanyBranch $company_branch) {
                return number_format($company_branch->balance, 2);
            })
            ->addColumn('action', function (CompanyBranch $company_branch) {
                $btn = ' <a class="btn btn-info btn-sm" href="' . route('company_branch_edit', ['company_branch' => $company_branch->id]) . '"> Edit </a> ';
                $btn .= ' <a class="btn btn-danger btn-sm" href="' . route('company_branch_delete', ['company_branch' => $company_branch->id]) . '" onclick="return confirm(\'Are you sure you want to delete ?\');"> Delete </a> ';
                return $btn;
            })
            ->rawColumns(['action', 'status'])
            ->toJson();
    }
}
