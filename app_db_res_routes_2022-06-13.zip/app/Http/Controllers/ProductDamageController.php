<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\InventoryLog;
use App\Models\Product;
use App\Models\TransactionLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;

class ProductDamageController extends Controller
{
    public function productDamages()
    {
        return view('product.damage.damages');
    }

    public function productDamageCreate()
    {
        $count = InventoryLog::where('client_id', Auth::user()->client_id)->where('stock_type', 4)->groupBy('invoice_no')->withTrashed()->count();
        $invoice_no = str_pad($count + 1, 5, 0, STR_PAD_LEFT);
        return view('product.damage.create', compact('invoice_no'));
    }

    public function productDamageStore(Request $request)
    {
        $request->validate([
            'date' => 'required|date',
            'code.*' => 'required',
            'product.*' => 'required',
            'quantity.*' => 'required|numeric|min:.01',
            'unit_price.*' => 'required|numeric|min:0',
        ]);

        $count = InventoryLog::where('client_id', Auth::user()->client_id)->groupBy('invoice_no')->where('stock_type', 4)->withTrashed()->count();
        $invoice_no = str_pad($count + 1, 5, 0, STR_PAD_LEFT);

        $account = Account::find(5);
        $sub_total = 0;
        foreach ($request->code as $key => $product_code) {
            $product = Product::where('client_id', Auth::user()->client_id)->where('code', $product_code)->first();
            if ($product) {
                // Inventory Log
                $inventory_log = InventoryLog::create([
                    'client_id' => Auth::user()->client_id,
                    'section_id' => 1,
                    'product_id' => $product->id,
                    'product_category_id' => $product->product_category_id,
                    'code' => $product_code,
                    'invoice_no' => $invoice_no,
                    'stock_type' => 4,
                    'type' => 2,
                    'date' => date('Y-m-d', strtotime($request->date)),
                    'discount' => 0,
                    'quantity' => $request->quantity[$key],
                    'unit_price' => $request->unit_price[$key],
                    'product_total' => $request->quantity[$key] * $request->unit_price[$key],
                    'total' => $request->quantity[$key] * $request->unit_price[$key],
                    'supplier_id' => null,
                    'purchase_order_id' => null,
                    'note' => "Product Damage",
                    'user_id' => Auth::id(),
                ]);

                // Damage Credit
                $voucher_count = TransactionLog::where('client_id', Auth::user()->client_id)->withTrashed()->count();
                TransactionLog::create([
                    'client_id' => Auth::user()->client_id,
                    'section_id' => 1,
                    'voucher_no' => str_pad($voucher_count + 1, 5, 0, STR_PAD_LEFT),
                    'transaction_type' => 2,
                    'date' => date('Y-m-d', strtotime($request->date)),
                    'particular' => "Damage product for invoice no. " . $invoice_no,
                    'account_class_id' => $account->account_class_id,
                    'account_head_id' => $account->account_head_id,
                    'account_id' => $account->account_id,
                    'inventory_log_id' => $inventory_log->id,
                    'supplier_id' => null,
                    'purchase_order_id' => null,
                    'payment_method' => null,
                    'bank_id' => null,
                    'credit' => $request->quantity[$key] * $request->unit_price[$key],
                    'amount' => $request->quantity[$key] * $request->unit_price[$key],
                    'note' => "Damage Product",
                    'user_id' => Auth::id(),
                    'status' => 1,
                ]);

                $sub_total += $request->quantity[$key] * $request->unit_price[$key];
            }
        }



        return redirect()->route('product_damages');
    }

    public function productDamageDelete(InventoryLog $inventory_log)
    {
        $transaction_log = TransactionLog::where('inventory_log_id', $inventory_log->id)->first();
        if ($transaction_log) {
            $transaction_log->update(['delete_user_id' => Auth::id()]);
            $transaction_log->delete();
        }

        $inventory_log->update(['delete_user_id' => Auth::id()]);
        $inventory_log->delete();

        return redirect()->back()->with('message', 'Damage product deleted successfully done.');
    }

    public function productDamageDatatable(Request $request)
    {
        $query = InventoryLog::where('client_id', Auth::user()->client_id)->where('stock_type', 4)->orderBy('id', 'desc');
        return DataTables::eloquent($query)
            ->addIndexColumn()
            ->editColumn('date', function (InventoryLog $inventory_log) {
                return $inventory_log->date->format('j F, Y');
            })
            ->editColumn('total', function (InventoryLog $inventory_log) {
                return number_format($inventory_log->total, 2);
            })
            ->editColumn('unit_price', function (InventoryLog $inventory_log) {
                return number_format($inventory_log->unit_price, 2);
            })
            ->addColumn('action', function (InventoryLog $inventory_log) {
                $btn = ' <a class="btn btn-danger btn-sm" href="' . route('product_damage_delete', ['inventory_log' => $inventory_log->id]) . '" onclick="return confirm(\'Are you sure you want to delete ?\');"> Delete </a> ';
                return $btn;
            })
            ->rawColumns(['action'])
            ->toJson();
    }
}
