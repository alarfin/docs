<?php

namespace App\Http\Controllers;

use App\Models\OnlineCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;

class OnlineCategoryController extends Controller
{
    public function index()
    {
        return view('online_category.all');
    }

    public function add()
    {
        return view('online_category.add');
    }

    public function store(Request $request)
    {

        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable',
            'status' => 'required'
        ]);

        $data = $request->all();
        $data['client_id'] = Auth::user()->client_id;
        $data['section_id'] = 6;
        $data['user_id'] = Auth::id();
        OnlineCategory::create($data);

        return redirect()->route('online_categories')->with('message', 'Online category added successfully.');
    }

    public function edit(OnlineCategory $online_category)
    {
        $this->clientCheck($online_category);
        return view('online_category.edit', compact('online_category'));
    }

    public function update(Request $request, OnlineCategory $online_category)
    {
        $this->clientCheck($online_category);
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable',
            'status' => 'required'
        ]);

        $data = $request->all();
        $online_category->update($data);

        return redirect()->route('online_categories')->with('message', 'Online category edit successfully.');
    }
    public function delete(OnlineCategory $online_category)
    {
        $this->clientCheck($online_category);
        $online_category->delete();
        return redirect()->route('online_categories')->with('message', 'Online category deleted successfully.');
    }

    public function onlineCategoryDatatable()
    {
        $query = OnlineCategory::where('client_id', Auth::user()->client_id);
        return DataTables::eloquent($query)
            ->addIndexColumn()
            ->editColumn('status', function (OnlineCategory $online_category) {
                if ($online_category->status == 1) {
                    return '<span class="label label-success">Active</span>';
                } else {
                    return '<span class="label label-danger">Inactive</span>';
                }
            })
            ->addColumn('action', function (OnlineCategory $online_category) {
                $btn = '';
                if ($online_category->default_status == 0) {
                    $btn .= ' <a class="btn btn-info btn-sm" href="' . route('online_category_edit', ['online_category' => $online_category->id]) . '"> Edit </a> ';
                    $btn .= ' <a class="btn btn-danger btn-sm" href="' . route('online_category_delete', ['online_category' => $online_category->id]) . '" onclick="return confirm(\'Are you sure you want to delete ?\');"> Delete </a> ';
                }
                return $btn;
            })
            ->rawColumns(['action', 'status'])
            ->toJson();
    }
}
