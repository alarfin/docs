<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Section;
use App\Models\User;
use App\Models\UserSection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;

class UserController extends Controller
{
    public function index()
    {
        $users = User::orderBy('name')->get();
        return view('administrator.user.all', compact('users'));
    }

    public function add()
    {
        $sections = Section::where('status', 1)->get();
        return view('administrator.user.add', compact('sections'));
    }

    public function addPost(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'mobile_no' => 'nullable|string|unique:users',
            'password' => 'required|string|min:8|confirmed'
        ]);


        $user = new User();
        $user->client_id = Auth::user()->client_id;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->mobile_no = $request->mobile_no;
        $user->password = bcrypt($request->password);
        $user->role_id = 2;
        $user->user_id = Auth::id();
        $user->save();

        // User Sections
        foreach ($request->section_ids ?? [] as $key => $section_id) {
            $section = Section::find($section_id);
            if ($section) {
                UserSection::create([
                    'user_id' => $user->id,
                    'section_id' => $section->id,
                    'creator_user_id' => Auth::id(),
                ]);
            }
        }

        // $user->syncPermissions($request->permission);

        return redirect()->route('user_all')->with('message', 'User add successfully.');
    }

    public function edit(User $user)
    {
        $this->clientCheck($user);
        $sections = Section::where('status', 1)->get();
        return view('administrator.user.edit', compact('user', 'sections'));
    }

    public function editPost(User $user, Request $request)
    {
        $this->clientCheck($user);
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'mobile_no' => 'nullable|string|unique:users,mobile_no,' . $user->id,
            'password' => 'nullable|string|min:8|confirmed'
        ]);

        $user->name = $request->name;
        $user->email = $request->email;
        $user->mobile_no = $request->mobile_no;
        if ($request->password) {
            $user->password = bcrypt($request->password);
        }
        $user->save();

        // Remove prev User Section
        UserSection::whereNotIn('section_id', $request->section_ids ?? [])->where('user_id', $user->id)->delete();
        foreach ($request->section_ids ?? [] as $key => $section_id) {
            $section = Section::find($section_id);
            if ($section) {
                $user_section = UserSection::where('user_id', $user->id)->where('section_id', $section->id)->first();
                if (empty($user_section)) {
                    UserSection::create([
                        'user_id' => $user->id,
                        'section_id' => $section->id,
                        'creator_user_id' => Auth::id(),
                    ]);
                }
            }
        }
        // $user->syncPermissions($request->permission);

        return redirect()->route('user_all')->with('message', 'User edit successfully.');
    }

    public function userDatatable(Request $request)
    {
        $query = User::with('sections', 'user')->where('client_id', Auth::user()->client_id)->whereIn('role_id', [1, 2]);

        return DataTables::eloquent($query)
            ->addIndexColumn()
            ->editColumn('sections', function (User $user) {
                $output = '';
                foreach ($user->sections as $user_section) {
                    $output .= ' <span class="label label-primary label-sm"> ' . $user_section->section->name ?? "" . ' </span> &nbsp;';
                }
                return $output;
            })
            ->editColumn('role_id', function (User $user) {
                if ($user->role_id == 1) {
                    return 'Super Admin ';
                } elseif ($user->role_id == 2) {
                    return 'Admin';
                } elseif ($user->role_id == 3) {
                    return 'Employee';
                }
            })
            ->editColumn('status', function (User $user) {
                if ($user->status == 1) {
                    return '<span>Enable</status>';
                } else {
                    return '<span>Disable</status>';
                }
            })
            ->addColumn('action', function (User $user) {
                $btn = '<a class="btn btn-info btn-sm" href="' . route('user_edit', ['user' => $user->id]) . '">Edit</a>';
                return $btn;
            })
            ->rawColumns(['action', 'sections', 'status', 'role_id'])
            ->toJson();
    }
}
