<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\AccountHeadSubType;
use App\Models\AccountHeadType;
use App\Models\Bank;
use App\Models\BankAccount;
use App\Models\Cash;
use App\Models\CompanyBranch;
use App\Models\Customer;
use App\Models\MobileBanking;
use App\Models\Product;
use App\Models\PurchaseInventory;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderProduct;
use App\Models\PurchaseProduct;
use App\Models\SalaryProcess;
use App\Models\SaleOrder;
use App\Models\SaleOrderProduct;
use App\Models\SalesOrder;
use App\Models\Section;
use App\Models\Supplier;
use App\Models\TransactionLog;
use App\Models\Year;
use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Auth;

class ReportController extends Controller
{
    public function salarySheet(Request $request)
    {
        $month = $request->month ?? date('m');
        $year = $request->year ?? date('Y');
        $salary_process = SalaryProcess::where('month', $month)->where('year', $year)->first();
        $branches = CompanyBranch::where('section_id', Auth::user()->logged_section_id)->where('status', 1)->get();
        $years = Year::where('status', 1)->get();
        // dd($salary_process);
        return view('report.salary_sheet', compact('salary_process', 'years', 'branches'));
    }

    public function chartOfAccounts(Request $request)
    {
        $accounts = Account::where('status', 1)->get();
        $searchData = null;
        $selected_section_id = $request->section_id ?? Auth::user()->logged_section_id;

        if ($selected_section_id && $request->section_id != "all") {
            $searchData['section_id'] = $selected_section_id;
        }
        if ($request->company_branch_id) {
            $searchData['company_branch_id'] = $request->company_branch_id;
        }
        if ($request->start_date && $request->end_date) {
            $searchData['start_date'] = $request->start_date;
            $searchData['end_date'] = $request->end_date;
        }
        $sections = $this->getSections();
        return view('report.chart_of_accounts', compact('accounts', 'searchData', 'sections', 'selected_section_id'));
    }

    public function trialBalance(Request $request)
    {
        $accounts = Account::where('status', 1)->get();
        $searchData = null;
        $selected_section_id = $request->section_id ?? Auth::user()->logged_section_id;
        if ($selected_section_id && $request->section_id != "all") {
            $searchData['section_id'] = $selected_section_id;
        }
        if ($request->company_branch_id) {
            $searchData['company_branch_id'] = $request->company_branch_id;
        }
        if ($request->start_date && $request->end_date) {
            $searchData['start_date'] = $request->start_date;
            $searchData['end_date'] = $request->end_date;
        }
        $sections = $this->getSections();
        return view('report.trial_balance', compact('accounts', 'searchData', 'sections', 'selected_section_id'));
    }

    public function supplierReport(Request $request)
    {
        $suppliers = Supplier::where('status', 1)->get();
        $searchData = null;
        $selected_section_id = $request->section_id ?? Auth::user()->logged_section_id;
        if ($selected_section_id && $request->section_id != "all") {
            $searchData['section_id'] = $selected_section_id;
        }
        if ($request->company_branch_id) {
            $searchData['company_branch_id'] = $request->company_branch_id;
        }
        if ($request->start_date && $request->end_date) {
            $searchData['start_date'] = $request->start_date;
            $searchData['end_date'] = $request->end_date;
        }
        $sections = $this->getSections();

        return view('report.supplier', compact('suppliers', 'searchData', 'sections', 'selected_section_id'));
    }

    public function customerReport(Request $request)
    {
        $customers = Customer::where('status', 1)->get();
        $searchData = null;
        $selected_section_id = $request->section_id ?? Auth::user()->logged_section_id;
        if ($selected_section_id && $request->section_id != "all") {
            $searchData['section_id'] = $selected_section_id;
        }
        if ($request->company_branch_id) {
            $searchData['company_branch_id'] = $request->company_branch_id;
        }
        if ($request->start_date && $request->end_date) {
            $searchData['start_date'] = $request->start_date;
            $searchData['end_date'] = $request->end_date;
        }
        $sections = $this->getSections();
        return view('report.customer', compact('customers', 'searchData', 'sections', 'selected_section_id'));
    }

    public function purchaseReport(Request $request)
    {
        $company_branches = $this->getCompanyBranches();
        $suppliers = Supplier::orderBy('name')->get();
        $start_date = $request->start_date ?? date('Y-m-d');
        $end_date = $request->end_date ?? date('Y-m-d');

        $query = PurchaseOrder::where('client_id', Auth::user()->client_id)->whereBetween('date', [$start_date, $end_date]);

        if ($request->company_branch_id) {
            $query->where('company_branch_id', $request->company_branch_id);
        }

        if ($request->supplier_id) {
            $query->where('supplier_id', $request->supplier_id);
        }

        if ($request->invoice_no) {
            $query->where('invoice_no', str_pad($request->invoice_no, 5, 0, STR_PAD_LEFT));
        }
        $query->orderBy('date', 'desc')->orderBy('created_at', 'desc');
        $orders = $query->get();
        return view('report.purchase', compact('company_branches', 'orders', 'suppliers', 'start_date', 'end_date'));
    }

    public function purchaseProductReport(Request $request)
    {
        $company_branches = $this->getCompanyBranches();
        $suppliers = Supplier::orderBy('name')->get();
        $products = Product::orderBy('name')->get();
        $start_date = $request->start_date ?? date('Y-m-d');
        $end_date = $request->end_date ?? date('Y-m-d');

        $query = PurchaseOrderProduct::where('client_id', Auth::user()->client_id)->whereBetween('return_at', [$start_date, $end_date]);

        if ($request->company_branch_id) {
            $query->where('company_branch_id', $request->company_branch_id);
        }

        if ($request->supplier_id) {
            $query->where('supplier_id', $request->supplier_id);
        }

        if ($request->product_id) {
            $query->where('product_id', $request->product_id);
        }

        if ($request->invoice_no) {
            $query->whereHas('purchaseOrder', function ($q) use ($request) {
                $q->where('invoice_no', str_pad($request->invoice_no, 5, 0, STR_PAD_LEFT));
            });
        }

        $query->orderBy('date', 'desc')->orderBy('created_at', 'desc');
        $orders = $query->get();
        return view('report.purchase_product', compact('company_branches', 'suppliers', 'orders', 'products', 'start_date', 'end_date'));
    }

    public function purchaseProductReturnReport(Request $request)
    {
        $company_branches = $this->getCompanyBranches();
        $suppliers = Supplier::orderBy('name')->get();
        $products = Product::orderBy('name')->get();
        $start_date = $request->start_date ?? date('Y-m-d');
        $end_date = $request->end_date ?? date('Y-m-d');

        $query = PurchaseOrderProduct::where('client_id', Auth::user()->client_id)->where('return_quantity', '>', 0)->whereBetween('date', [$start_date, $end_date]);

        if ($request->company_branch_id) {
            $query->where('company_branch_id', $request->company_branch_id);
        }

        if ($request->supplier_id) {
            $query->where('supplier_id', $request->supplier_id);
        }

        if ($request->product_id) {
            $query->where('product_id', $request->product_id);
        }

        if ($request->invoice_no) {
            $query->whereHas('purchaseOrder', function ($q) use ($request) {
                $q->where('invoice_no', str_pad($request->invoice_no, 5, 0, STR_PAD_LEFT));
            });
        }

        $query->orderBy('date', 'desc')->orderBy('created_at', 'desc');
        $orders = $query->get();
        return view('report.purchase_product_return', compact('company_branches', 'suppliers', 'orders', 'products', 'start_date', 'end_date'));
    }

    public function saleReport(Request $request)
    {
        $company_branches = $this->getCompanyBranches();
        $start_date = $request->start_date ?? date('Y-m-d');
        $end_date = $request->end_date ?? date('Y-m-d');

        $query = SaleOrder::where('client_id', Auth::user()->client_id)->whereBetween('date', [$start_date, $end_date]);

        if ($request->company_branch_id) {
            $query->where('company_branch_id', $request->company_branch_id);
        }

        if ($request->customer_id) {
            $query->where('customer_id', $request->customer_id);
        }

        if ($request->invoice_no) {
            $query->where('invoice_no', str_pad($request->invoice_no, 5, 0, STR_PAD_LEFT));
        }
        $query->orderBy('date', 'desc')->orderBy('created_at', 'desc');
        $orders = $query->get();
        return view('report.sale', compact('company_branches', 'orders', 'start_date', 'end_date'));
    }

    public function saleProductReport(Request $request)
    {
        $company_branches = $this->getCompanyBranches();
        $products = Product::orderBy('name')->get();
        $start_date = $request->start_date ?? date('Y-m-d');
        $end_date = $request->end_date ?? date('Y-m-d');

        $query = SaleOrderProduct::where('client_id', Auth::user()->client_id)->whereBetween('date', [$start_date, $end_date]);

        if ($request->company_branch_id) {
            $query->where('company_branch_id', $request->company_branch_id);
        }

        if ($request->customer_id) {
            $query->where('customer_id', $request->customer_id);
        }

        if ($request->product_id) {
            $query->where('product_id', $request->product_id);
        }

        if ($request->invoice_no) {
            $query->whereHas('saleOrder', function ($q) use ($request) {
                $q->where('invoice_no', str_pad($request->invoice_no, 5, 0, STR_PAD_LEFT));
            });
        }

        $query->orderBy('date', 'desc')->orderBy('created_at', 'desc');
        $orders = $query->get();
        return view('report.sale_product', compact('company_branches', 'orders', 'products', 'start_date', 'end_date'));
    }

    public function saleProductReturnReport(Request $request)
    {
        $company_branches = $this->getCompanyBranches();
        $products = Product::orderBy('name')->get();
        $start_date = $request->start_date ?? date('Y-m-d');
        $end_date = $request->end_date ?? date('Y-m-d');

        $query = SaleOrderProduct::where('client_id', Auth::user()->client_id)->where('return_quantity', '>', 0)->whereBetween('date', [$start_date, $end_date]);

        if ($request->company_branch_id) {
            $query->where('company_branch_id', $request->company_branch_id);
        }

        if ($request->customer_id) {
            $query->where('customer_id', $request->customer_id);
        }

        if ($request->product_id) {
            $query->where('product_id', $request->product_id);
        }

        if ($request->invoice_no) {
            $query->whereHas('saleOrder', function ($q) use ($request) {
                $q->where('invoice_no', str_pad($request->invoice_no, 5, 0, STR_PAD_LEFT));
            });
        }

        $query->orderBy('date', 'desc')->orderBy('created_at', 'desc');
        $orders = $query->get();
        return view('report.sale_product_return', compact('company_branches', 'orders', 'products', 'start_date', 'end_date'));
    }

    public function ledgerReport(Request $request)
    {
        $start_date = $request->start_date ?? date('Y-m-d');
        $end_date = $request->end_date ?? date('Y-m-d');
        $accounts = Account::where('status', 1)->get();
        $suppliers = Supplier::where('status', 1)->get();
        $show_data = null;

        $query = TransactionLog::orderBy('date', 'desc')->where('client_id', Auth::id())->where('status', 1)
            ->whereBetween('date', [$start_date, $end_date]);

        $selected_section_id = $request->section_id ?? Auth::user()->logged_section_id;

        if ($selected_section_id && $request->section_id != "all") {
            $query->where('section_id', $selected_section_id);
            $show_data['section'] = Section::find($selected_section_id);
        }

        if ($request->company_branch_id) {
            $query->where('company_branch_id', $request->company_branch_id);
            $show_data['company_branch'] = CompanyBranch::find($request->company_branch_id);
        }

        if ($request->account_id) {
            $query->where('account_id', $request->account_id);
            $show_data['account_id'] = Account::find($request->account_id);
        }

        if ($request->supplier_id) {
            $query->where('supplier_id', $request->supplier_id);
            $show_data['supplier'] = Supplier::find($request->supplier_id);
        }

        if ($request->customer_id) {
            $query->where('customer_id', $request->customer_id);
            $show_data['customer'] = Customer::find($request->customer_id);
        }

        $ledgers = $query->orderBy('id', 'desc')->get();
        $sections = $this->getSections();

        return view('report.ledger', compact('ledgers', 'accounts', 'suppliers', 'sections', 'selected_section_id', 'start_date', 'end_date', 'show_data'));
    }

    public function cashBankStatement(Request $request)
    {
        $start_date = $request->start_date ?? date('Y-m-d');
        $end_date = $request->end_date ?? date('Y-m-d');
        $accounts = Account::whereIn('id', [3, 4])->get();
        $banks = Bank::where('status', 1)->get();
        $show_data = null;

        $query = TransactionLog::orderBy('date', 'desc')->where('client_id', Auth::id())->where('status', 1)
            ->whereBetween('date', [$start_date, $end_date])->whereIn('account_id', [3, 4]);

        $selected_section_id = $request->section_id ?? Auth::user()->logged_section_id;

        if ($selected_section_id && $request->section_id != "all") {
            $query->where('section_id', $selected_section_id);
            $show_data['section'] = Section::find($selected_section_id);
        }

        if ($request->company_branch_id) {
            $query->where('company_branch_id', $request->company_branch_id);
            $show_data['company_branch'] = CompanyBranch::find($request->company_branch_id);
        }

        if ($request->account_id) {
            $query->where('account_id', $request->account_id);
            $show_data['account'] = Account::find($request->account_id);
        }

        if ($request->bank_id) {
            $query->where('bank_id', $request->bank_id);
            $show_data['bank'] = Bank::find($request->bank_id);
        }

        $transaction_logs = $query->orderBy('id', 'desc')->get();
        $sections = $this->getSections();

        return view('report.cash_bank_statement', compact('transaction_logs', 'banks', 'accounts', 'sections', 'selected_section_id', 'start_date', 'end_date', 'show_data'));
    }

    public function stockReport(Request $request)
    {
        $products = Product::where('status', 1)->get();
        $show_data = null;
        $searchData = null;
        $searchData['start_date'] = $request->start_date ?? date('Y-m-d');
        $searchData['end_date'] = $request->end_date ?? date('Y-m-d');

        $selected_section_id = $request->section_id ?? Auth::user()->logged_section_id;
        if ($selected_section_id && $request->section_id != "all") {
            $searchData['section_id'] = $selected_section_id;
            $show_data['section'] = Section::find($selected_section_id);
        }

        if ($request->company_branch_id) {
            $searchData['company_branch_id'] = $request->company_branch_id;
            $show_data['company_branch'] = CompanyBranch::find($request->company_branch_id);
        }

        $sections = $this->getSections();

        return view('report.stock', compact('products', 'searchData', 'sections', 'selected_section_id', 'show_data'));
    }

    public function balanceSummary(Request $request)
    {
        $cash_account = Account::find(3);
        $bank_account = Account::find(4);
        $capital_account = Account::find(6);
        $banks = Bank::where('client_id', Auth::user()->client_id)->get();
        $show_data = null;
        $searchData = null;
        $searchData['date'] = $request->date ?? date('Y-m-d');

        $selected_section_id = $request->section_id ?? Auth::user()->logged_section_id;
        if ($selected_section_id && $request->section_id != "all") {
            $searchData['section_id'] = $selected_section_id;
            $show_data['section'] = Section::find($selected_section_id);
        }

        if ($request->company_branch_id) {
            $searchData['company_branch_id'] = $request->company_branch_id;
            $show_data['company_branch'] = CompanyBranch::find($request->company_branch_id);
        }


        $sections = $this->getSections();

        return view('report.balance_summary', compact(
            'cash_account',
            'bank_account',
            'capital_account',
            'banks',
            'searchData',
            'sections',
            'selected_section_id',
            'show_data'
        ));
    }


    public function balanceSheet()
    {
        $bankAccounts = BankAccount::where('status', 1)->with('bank', 'branch')->get();
        $cash = Cash::first();
        $mobileBanking = MobileBanking::first();
        $customerTotalPaid = Customer::all()->sum('due');
        $suppliers = Supplier::all();
        $totalInventory = PurchaseInventory::select(DB::raw('SUM(`selling_price` * `quantity`) AS total'))
            ->get();

        return view('report.balance_sheet', compact(
            'bankAccounts',
            'cash',
            'mobileBanking',
            'customerTotalPaid',
            'suppliers',
            'totalInventory'
        ));
    }

    public function profitAndLoss(Request $request)
    {
        $incomes = null;
        $expenses = null;

        if ($request->start && $request->end) {
            $incomes = TransactionLog::where('transaction_type', 1)->whereBetween('date', [$request->start, $request->end])->get();
            $expenses = TransactionLog::whereIn('transaction_type', [4, 2])->whereBetween('date', [$request->start, $request->end])->get();
        }

        return view('report.profit_and_loss', compact('incomes', 'expenses'));
    }
}
