<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Bank;
use App\Models\CompanyBranch;
use App\Models\Customer;
use App\Models\OnlineCategory;
use App\Models\OnlineInformation;
use App\Models\TransactionLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\Facades\DataTables;

class OnlineInformationController extends Controller
{
    public function index()
    {
        $banks = Bank::where('client_id', Auth::user()->client_id)->where('status', 1)->get();
        return view('online_information.all', compact('banks'));
    }

    public function add()
    {
        $online_categories = OnlineCategory::where('client_id', Auth::user()->client_id)->where('status', 1)->get();
        $count = OnlineInformation::where('client_id', Auth::user()->client_id)->withTrashed()->count();
        $serial_no = str_pad($count + 1, 5, 0, STR_PAD_LEFT);
        $banks = Bank::where('client_id', Auth::user()->client_id)->where('status', 1)->get();
        $branches = CompanyBranch::where('client_id', Auth::user()->client_id)->where('section_id', Auth::user()->logged_section_id)->where('status', 1)->get();

        return view('online_information.add', compact('online_categories', 'serial_no', 'banks', 'branches'));
    }

    public function store(Request $request)
    {

        $request->validate([
            'company_branch_id' => 'required',
            'customer_id' => 'required',
            'date' => 'required|date',
            'online_category_id' => 'required',
            'name' => 'required|string|max:255',
            'total' => 'required|numeric',
            'paid' => 'required|numeric',
        ]);
        $due = $request->total - $request->paid;
        $customer = Customer::find($request->customer_id);

        $data = $request->all();
        $count = OnlineInformation::where('client_id', Auth::user()->client_id)->withTrashed()->count();

        $data['serial_no'] = str_pad($count + 1, 5, 0, STR_PAD_LEFT);
        $data['due'] = $due;
        $data['client_id'] = Auth::user()->client_id;
        $data['section_id'] = 6;
        $data['user_id'] = Auth::id();
        $online_information = OnlineInformation::create($data);

        // Online Information Credit
        $account = Account::find(11);
        $voucher_count = TransactionLog::where('client_id', Auth::user()->client_id)->withTrashed()->count();
        TransactionLog::create([
            'client_id' => Auth::user()->client_id,
            'section_id' => 6,
            'company_branch_id' => $request->company_branch_id,
            'voucher_no' => str_pad($voucher_count + 1, 5, 0, STR_PAD_LEFT),
            'transaction_type' => 10,
            'date' => date('Y-m-d', strtotime($request->date)),
            'particular' => "Online information for serial no. " . $online_information->serial_no,
            'account_class_id' => $account->account_class_id,
            'account_head_id' => $account->account_head_id,
            'account_id' => $account->id,
            'customer_id' => $customer->id,
            'online_information_id' => $online_information->id,
            'payment_method' => null,
            'bank_id' => null,
            'credit' => $online_information->total,
            'amount' => $online_information->total,
            'note' => "Online information for " . $customer->name ?? null,
            'user_id' => Auth::id(),
            'status' => 1,
        ]);

        //  Receive payment
        if ($request->payment_method == 1) {
            $payment_account = Account::find(3);
        } elseif ($request->payment_method == 2) {
            $payment_account = Account::find(4);
        } else {
            $payment_account = Account::find(5);
        }

        if ($request->paid > 0) {
            $voucher_count2 = TransactionLog::where('client_id', Auth::user()->client_id)->withTrashed()->count();
            TransactionLog::create([
                'client_id' => Auth::user()->client_id,
                'section_id' => 6,
                'company_branch_id' => $request->company_branch_id,
                'voucher_no' => str_pad($voucher_count2 + 1, 5, 0, STR_PAD_LEFT),
                'transaction_type' => 1,
                'date' => date('Y-m-d', strtotime($request->date)),
                'particular' => "Online information receive for serial no. " . $online_information->serial_no,
                'account_class_id' => $payment_account->account_class_id,
                'account_head_id' => $payment_account->account_head_id,
                'account_id' => $payment_account->id,
                'customer_id' => $customer->id,
                'online_information_id' => $online_information->id,
                'payment_method' => $request->payment_method ?? null,
                'bank_id' => $request->bank_id ?? null,
                'credit' => $request->paid,
                'amount' => $request->paid,
                'note' => "Online information receive from" . $customer->name ?? null,
                'user_id' => Auth::id(),
                'status' => 1,
            ]);
        }

        if ($request->paid != $online_information->total) {
            $amount = $online_information->total - $request->paid;
            $receivable = Account::find(13);
            $voucher_count3 = TransactionLog::where('client_id', Auth::user()->client_id)->withTrashed()->count();
            TransactionLog::create([
                'client_id' => Auth::user()->client_id,
                'section_id' => 6,
                'company_branch_id' => $request->company_branch_id,
                'voucher_no' => str_pad($voucher_count3 + 1, 5, 0, STR_PAD_LEFT),
                'transaction_type' => 10,
                'date' => date('Y-m-d', strtotime($request->date)),
                'particular' => "Customer receivable for serial no. " . $online_information->serial,
                'account_class_id' => $receivable->account_class_id,
                'account_head_id' => $receivable->account_head_id,
                'account_id' => $receivable->id,
                'customer_id' => $customer->id,
                'online_information_id' => $online_information->id,
                'payment_method' => null,
                'bank_id' => null,
                'credit' => $amount,
                'amount' => $amount,
                'note' => "Online information receivable from " . $customer->name ?? null,
                'user_id' => Auth::id(),
                'status' => 1,
            ]);
        }

        return redirect()->route('online_informations')->with('message', 'Online information added successfully.');
    }

    public function details(OnlineInformation $online_information)
    {
        $this->clientCheck($online_information);
        return view('online_information.details', compact('online_information'));
    }

    public function edit(OnlineInformation $online_information)
    {
        $this->clientCheck($online_information);
        $online_categories = OnlineCategory::where('client_id', Auth::user()->client_id)->where('status', 1)->get();
        $banks = Bank::where('client_id', Auth::user()->client_id)->where('status', 1)->get();
        $branches = CompanyBranch::where('client_id', Auth::user()->client_id)->where('section_id', Auth::user()->logged_section_id)->where('status', 1)->get();

        return view('online_information.edit', compact('online_information', 'online_categories', 'banks', 'branches'));
    }

    public function update(Request $request, OnlineInformation $online_information)
    {
        $this->clientCheck($online_information);
        $request->validate([
            'company_branch_id' => 'required',
            'customer_id' => 'required',
            'date' => 'required|date',
            'online_category_id' => 'required',
            'name' => 'required|string|max:255',
            'total' => 'required|numeric',
            'paid' => 'required|numeric',
        ]);
        $due = $request->total - $request->paid;
        $customer = Customer::find($request->customer_id);

        $data = $request->all();
        $data['due'] = $due;
        $online_information->update($data);

        // Online Information Credit
        $account = Account::find(11);
        $transaction_log1 = TransactionLog::where('client_id', Auth::user()->client_id)->where('account_id', $account->id)->where('online_information_id', $online_information->id)->first();

        $transaction_log1->update([
            'date' => date('Y-m-d', strtotime($request->date)),
            'customer_id' => $customer->id,
            'credit' => $online_information->total,
            'amount' => $online_information->total,
        ]);

        //  Receive payment
        if ($request->payment_method == 1) {
            $payment_account = Account::find(3);
        } elseif ($request->payment_method == 2) {
            $payment_account = Account::find(4);
        } else {
            $payment_account = Account::find(5);
        }

        if ($request->paid > 0) {
            $transaction_log2 = TransactionLog::where('client_id', Auth::user()->client_id)->whereIn('account_id', [3, 4, 5, 6])->where('online_information_id', $online_information->id)->first();
            if ($transaction_log2) {
                $transaction_log2->update([
                    'date' => date('Y-m-d', strtotime($request->date)),
                    'account_class_id' => $payment_account->account_class_id,
                    'account_head_id' => $payment_account->account_head_id,
                    'account_id' => $payment_account->id,
                    'customer_id' => $customer->id,
                    'payment_method' => $request->payment_method ?? null,
                    'bank_id' => $request->bank_id ?? null,
                    'credit' => $request->paid,
                    'amount' => $request->paid,
                    'status' => 1,
                ]);
            } else {
                $voucher_count2 = TransactionLog::where('client_id', Auth::user()->client_id)->withTrashed()->count();
                TransactionLog::create([
                    'client_id' => Auth::user()->client_id,
                    'section_id' => 6,
                    'company_branch_id' => $request->company_branch_id,
                    'voucher_no' => str_pad($voucher_count2 + 1, 5, 0, STR_PAD_LEFT),
                    'transaction_type' => 1,
                    'date' => date('Y-m-d', strtotime($request->date)),
                    'particular' => "Online information receive for serial no. " . $online_information->serial_no,
                    'account_class_id' => $payment_account->account_class_id,
                    'account_head_id' => $payment_account->account_head_id,
                    'account_id' => $payment_account->id,
                    'customer_id' => $customer->id,
                    'online_information_id' => $online_information->id,
                    'payment_method' => $request->payment_method ?? null,
                    'bank_id' => $request->bank_id ?? null,
                    'credit' => $request->paid,
                    'amount' => $request->paid,
                    'note' => "Online information receive from" . $customer->name ?? null,
                    'user_id' => Auth::id(),
                    'status' => 1,
                ]);
            }
        }

        $receivable = Account::find(13);
        $amount = $online_information->total - $request->paid;
        $transaction_log3 = TransactionLog::where('client_id', Auth::user()->client_id)->where('account_id', 13)->where('online_information_id', $online_information->id)->first();

        if ($transaction_log3) {
            $transaction_log3->update([
                'date' => date('Y-m-d', strtotime($request->date)),
                'customer_id' => $customer->id,
                'credit' => $amount,
                'amount' => $amount,
            ]);
        } else {
            if ($request->paid != $online_information->total) {
                $voucher_count3 = TransactionLog::where('client_id', Auth::user()->client_id)->withTrashed()->count();
                TransactionLog::create([
                    'client_id' => Auth::user()->client_id,
                    'section_id' => 6,
                    'company_branch_id' => $request->company_branch_id,
                    'voucher_no' => str_pad($voucher_count3 + 1, 5, 0, STR_PAD_LEFT),
                    'transaction_type' => 10,
                    'date' => date('Y-m-d', strtotime($request->date)),
                    'particular' => "Customer receivable for serial no. " . $online_information->serial,
                    'account_class_id' => $receivable->account_class_id,
                    'account_head_id' => $receivable->account_head_id,
                    'account_id' => $receivable->id,
                    'customer_id' => $customer->id,
                    'online_information_id' => $online_information->id,
                    'payment_method' => null,
                    'bank_id' => null,
                    'credit' => $amount,
                    'amount' => $amount,
                    'note' => "Online information receivable from " . $customer->name ?? null,
                    'user_id' => Auth::id(),
                    'status' => 1,
                ]);
            }
        }


        return redirect()->route('online_informations')->with('message', 'Online information updated successfully.');
    }

    public function delete(OnlineCategory $online_category)
    {
        $this->clientCheck($online_category);
        $online_category->delete();
        return redirect()->route('online_categories')->with('message', 'Online category deleted successfully.');
    }

    public function payment(Request $request)
    {
        $rules = [
            'online_information_id' => 'required',
            'payment_method' => 'required',
            'amount' => 'required|numeric|min:0',
            'date' => 'required|date',
            'note' => 'nullable|string|max:255',
        ];

        if ($request->payment_method == '2') {
            $rules['bank_id'] = 'required';
        }

        $online_information = OnlineInformation::find($request->online_information_id);
        if ($request->online_information_id != '') {
            $rules['amount'] = 'required|numeric|min:0|max:' . $online_information->due;
        }

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => $validator->errors()->first()]);
        }

        $online_information = OnlineInformation::find($request->online_information_id);

        $customer = Customer::find($online_information->customer_id);

        //  Receive payment
        if ($request->payment_method == 1) {
            $payment_account = Account::find(3);
        } elseif ($request->payment_method == 2) {
            $payment_account = Account::find(4);
        } else {
            $payment_account = Account::find(5);
        }

        if ($request->amount > 0) {
            $voucher_count = TransactionLog::where('client_id', Auth::user()->client_id)->withTrashed()->count();
            TransactionLog::create([
                'client_id' => Auth::user()->client_id,
                'section_id' => 6,
                'company_branch_id' => $request->company_branch_id,
                'voucher_no' => str_pad($voucher_count + 1, 5, 0, STR_PAD_LEFT),
                'transaction_type' => 1,
                'date' => date('Y-m-d', strtotime($request->date)),
                'particular' => "Online information due receive for serial no. " . $online_information->serial_no,
                'account_class_id' => $payment_account->account_class_id,
                'account_head_id' => $payment_account->account_head_id,
                'account_id' => $payment_account->id,
                'customer_id' => $customer->id,
                'online_information_id' => $online_information->id,
                'payment_method' => $request->payment_method ?? null,
                'bank_id' => $request->bank_id ?? null,
                'credit' => $request->amount,
                'amount' => $request->amount,
                'note' => "Online information due receive from" . $customer->name ?? null,
                'user_id' => Auth::id(),
                'status' => 1,
            ]);

            $transaction_receiveable = TransactionLog::where('client_id', Auth::user()->client_id)->where('account_id', 13)->where('online_information_id', $online_information->id)->first();
            if ($transaction_receiveable) {
                $transaction_receiveable->update([
                    'credit' => $transaction_receiveable->credit - $request->amount,
                    'amount' => $transaction_receiveable->amount - $request->amount,
                ]);
            }

            $online_information->paid = $online_information->paid + $request->amount;
            $online_information->due = $online_information->total + $online_information->paid;
            $online_information->save();
        }

        return response()->json(['success' => true, 'message' => 'Payment has been completed.']);
    }

    public function onlineInformationDatatable(Request $request)
    {
        $query = OnlineInformation::with('companyBranch', 'customer')->where('client_id', Auth::user()->client_id)->orderBy('id', 'desc');
        return DataTables::eloquent($query)
            ->addIndexColumn()
            ->addColumn('company_branch_name', function (OnlineInformation $online_information) {
                return $online_information->companyBranch->name ?? '';
            })
            ->addColumn('customer_name', function (OnlineInformation $online_information) {
                return $online_information->customer->name ?? '';
            })
            ->addColumn('customer_mobile_no', function (OnlineInformation $online_information) {
                return $online_information->customer->mobile_no ?? '';
            })
            ->editColumn('date', function (OnlineInformation $online_information) {
                return $online_information->date->format('d-m-Y');
            })
            ->editColumn('status', function (OnlineInformation $online_information) {
                if ($online_information->status == 1) {
                    return '<span class="label label-success">Active</span>';
                } else {
                    return '<span class="label label-danger">Inactive</span>';
                }
            })
            ->addColumn('action', function (OnlineInformation $online_information) {
                $btn = ' <a href="' . route('online_information_details', ['online_information' => $online_information->id]) . '" class="btn btn-info btn-sm">View</a> ';
                if ($online_information->due > 0) {
                    $btn .= ' <a role="button" class="btn btn-success btn-sm btn-pay" data-id="' . $online_information->id . '" data-name="' . $online_information->customer->name . '" data-amount="' . $online_information->due . '"> Pay </a> ';
                }
                $btn .= ' <a href="' . route('online_information_edit', ['online_information' => $online_information->id]) . '" class="btn btn-primary btn-sm"> Edit </a> ';
                // $btn .= ' <a href="' . route('online_information_delete', ['online_information' => $online_information->id]) . '" class="btn btn-danger btn-sm" onclick="return confirm(\'Are you sure you want to delete ?\');">Delete</a> ';
                return $btn;
            })
            ->rawColumns(['action', 'status'])
            ->toJson();
    }
}
