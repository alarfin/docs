<?php

namespace App\Http\Controllers;

use App\Models\Section;
use App\Models\UserSection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SectionController extends Controller
{
    public function index()
    {
        $sections = Section::where('status', 1)->get();
        return view('administrator.section.all', compact('sections'));
    }

    public function sectionLogin()
    {
        if (!UserSection::where('user_id', Auth::id())->first()) {
            Auth::logout();
            return redirect('login')->with('error', 'You have no section for access.');
        }
        if (Auth::user()->role_id == 1) {
            $sections = Section::where('status', 1)->get();
        } else {
            $sections = Section::where('status', 1)->get();
        }
        return view('layouts.section_login', compact('sections'));
    }

    public function goToDashboard($type)
    {
        $section = Section::where('url_name', $type)->first();
        $user = Auth::user();
        $user->logged_section_id = $section->id;
        $user->save();
        return redirect()->route('dashboard');
    }
}
