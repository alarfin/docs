<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductUnit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;

class ProductController extends Controller
{
    public function index()
    {
        return view('product.product.all');
    }

    public function add()
    {
        $product_categories = ProductCategory::where('status', 1)->get();
        $product_units = ProductUnit::where('status', 1)->get();
        $last_code = Product::orderBy('id', 'desc')->where('client_id', Auth::user()->client_id)->withTrashed()->count();
        $code = str_pad($last_code + 1, 5, 0, STR_PAD_LEFT);

        return view('product.product.add', compact('product_categories', 'product_units', 'code'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'product_category_id' => 'required',
            'product_unit_id' => 'required',
            'code' => 'nullable|string|max:255|unique:products',
            'buy_price' => 'required|numeric',
            'sale_price' => 'required|numeric',
            'whole_sale_price' => 'required|numeric',
            'tax' => 'required|numeric',
            'vat' => 'required|numeric',
            'description' => 'nullable|string|max:255',
            'status' => 'required'
        ]);
        $last_code = Product::orderBy('id', 'desc')->where('client_id', Auth::user()->client_id)->withTrashed()->count();

        $data = $request->all();
        $data['code'] = str_pad($last_code + 1, 5, 0, STR_PAD_LEFT);
        $data['user_id'] = Auth::id();
        $product = Product::create($data);

        return redirect()->route('products')->with('message', 'Product add successfully.');
    }

    public function edit(Product $product)
    {
        $this->clientCheck($product);
        $product_categories = ProductCategory::where('status', 1)->get();
        $product_units = ProductUnit::where('status', 1)->get();
        return view('product.product.edit', compact('product', 'product_categories', 'product_units'));
    }

    public function update(Request $request, Product $product)
    {
        $this->clientCheck($product);
        $request->validate([
            'name' => 'required|string|max:255',
            'product_unit_id' => 'required',
            'buy_price' => 'required|numeric',
            'sale_price' => 'required|numeric',
            'whole_sale_price' => 'required|numeric',
            'tax' => 'required|numeric',
            'vat' => 'required|numeric',
            'description' => 'nullable|string|max:255',
            'status' => 'required'
        ]);
        $data = $request->except('code');
        $product->update($data);

        return redirect()->route('products')->with('message', 'Product edit successfully.');
    }

    public function delete(Product $product)
    {
        $this->clientCheck($product);
        $product->delete();
        return redirect()->route('products')->with('message', 'Product delete successfully.');
    }

    public function barcodePrint(Request $request)
    {
        $product = Product::find($request->product_id);
        $quantity = $request->quantity;
        return view('product.generate_code.barcode_print', compact('product', 'quantity'));
    }
    public function qrcodePrint(Request $request)
    {
        $product = Product::find($request->product_id);
        $quantity = $request->quantity;
        return view('product.generate_code.qrcode_print', compact('product', 'quantity'));
    }

    public function productDatatable()
    {
        $query = Product::with('productCategory', 'productUnit')->where('client_id', Auth::user()->client_id);

        return DataTables::eloquent($query)
            ->addIndexColumn()
            ->addColumn('product_category', function (Product $product) {
                return $product->productCategory->name ?? '';
            })
            ->addColumn('product_unit', function (Product $product) {
                return $product->productUnit->name ?? '';
            })
            ->editColumn('status', function (Product $product) {
                if ($product->status == 1) {
                    return '<span class="label label-success">Active</span>';
                } else {
                    return '<span class="label label-danger">Inactive</span>';
                }
            })
            ->addColumn('action', function (Product $product) {
                $btn = ' <a class="btn btn-info btn-sm" href="' . route('product_edit', ['product' => $product->id]) . '">Edit</a> ';
                $btn .= ' <a class="btn btn-danger btn-sm" href="' . route('product_delete', ['product' => $product->id]) . '" onclick="return confirm(\'Are you sure you want to delete ?\');"> Delete </a> ';
                return $btn;
            })
            ->rawColumns(['action', 'status'])
            ->toJson();
    }
}
