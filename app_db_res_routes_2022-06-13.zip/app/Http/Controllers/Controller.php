<?php

namespace App\Http\Controllers;

use App\Models\CompanyBranch;
use App\Models\Section;
use App\Models\UserSection;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function clientCheck($data)
    {
        if (Auth::user()->client_id == $data['client_id']) {
            return true;
        } else {
            abort(404);
        }
    }

    public function getSections()
    {
        if (Auth::user()->role_id == 1) {
            return Section::where('status', 1)->get();
        } else {
            return Section::whereIn('id', UserSection::where('user_id', Auth::id())->pluck('section_id'))->get();
        }
    }

    public function getCompanyBranches()
    {
        return CompanyBranch::where('section_id', Auth::user()->logged_section_id)->get();
    }
}
