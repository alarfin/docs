<?php

namespace App\Installer;

use Exception;
use Illuminate\Database\SQLiteConnection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;
use Symfony\Component\Console\Output\BufferedOutput;

class Installer
{
    public function __construct()
    {
        self::$permission_results['permissions'] = [];
        self::$permission_results['errors'] = null;
    }

    /*************
     *  ENV or Environment Management
     */
    public static function getEnvContent()
    {
        if (!file_exists(base_path('.env'))) {
            if (file_exists(base_path('.env.example'))) {
                copy(base_path('.env.example'), base_path('.env'));
            } else {
                touch(base_path('.env'));
            }
        }
        return file_get_contents(base_path('.env'));
    }

    public static function getEnvPath()
    {
        return base_path('.env');
    }

    public static function getEnvExamplePath()
    {
        return base_path('.env.example');
    }

    public static function saveFileClassic(Request $request)
    {
        $message = __('installer_messages.environment_success');
        try {
            file_put_contents(self::getEnvPath(), $request->get('envConfig'));
        } catch (Exception $e) {
            $message = __('installer_messages.environment_errors');
        }
        return $message;
    }

    public static function saveFileWizard(Request $request)
    {
        $results = __('installer_messages.environment_success');

        $envFileData =
            'APP_INSTALLED=\'' . true . "'\n" .
            'APP_NAME=\'' . $request->app_name . "'\n" .
            'APP_ENV=' . $request->environment . "\n" .
            'APP_KEY=' . 'base64:' . base64_encode(Str::random(32)) . "\n" .
            'APP_DEBUG=' . $request->app_debug . "\n" .
            'APP_LOG_LEVEL=' . $request->app_log_level . "\n" .
            'APP_URL=' . $request->app_url . "\n\n" .
            'DB_CONNECTION=' . $request->database_connection . "\n" .
            'DB_HOST=' . $request->database_hostname . "\n" .
            'DB_PORT=' . $request->database_port . "\n" .
            'DB_DATABASE=' . $request->database_name . "\n" .
            'DB_USERNAME=' . $request->database_username . "\n" .
            'DB_PASSWORD=' . $request->database_password . "\n\n" .
            'BROADCAST_DRIVER=' . $request->broadcast_driver . "\n" .
            'CACHE_DRIVER=' . $request->cache_driver . "\n" .
            'SESSION_DRIVER=' . $request->session_driver . "\n" .
            'QUEUE_DRIVER=' . $request->queue_driver . "\n\n" .
            'REDIS_HOST=' . $request->redis_hostname . "\n" .
            'REDIS_PASSWORD=' . $request->redis_password . "\n" .
            'REDIS_PORT=' . $request->redis_port . "\n\n" .
            'MAIL_DRIVER=' . $request->mail_driver . "\n" .
            'MAIL_HOST=' . $request->mail_host . "\n" .
            'MAIL_PORT=' . $request->mail_port . "\n" .
            'MAIL_USERNAME=' . $request->mail_username . "\n" .
            'MAIL_PASSWORD=' . $request->mail_password . "\n" .
            'MAIL_ENCRYPTION=' . $request->mail_encryption . "\n\n" .
            'PUSHER_APP_ID=' . $request->pusher_app_id . "\n" .
            'PUSHER_APP_KEY=' . $request->pusher_app_key . "\n" .
            'PUSHER_APP_SECRET=' . $request->pusher_app_secret;

        try {
            file_put_contents(self::getEnvPath(), $envFileData);
        } catch (Exception $e) {
            $results = __('installer_messages.environment_errors');
        }

        return $results;
    }

    public static function checkDatabaseConnection(Request $request)
    {
        $connection = $request->input('database_connection');

        $settings = config("database.connections.$connection");

        config([
            'database' => [
                'default' => $connection,
                'connections' => [
                    $connection => array_merge($settings, [
                        'driver' => $connection,
                        'host' => $request->input('database_hostname'),
                        'port' => $request->input('database_port'),
                        'database' => $request->input('database_name'),
                        'username' => $request->input('database_username'),
                        'password' => $request->input('database_password'),
                    ]),
                ],
            ],
        ]);

        DB::purge();

        try {
            DB::connection()->getPdo();

            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /************
     *  Database Manager
     */
    public static function migrateAndSeed()
    {
        $outputLog = new BufferedOutput;
        self::sqlite($outputLog);
        return self::migrate($outputLog);
    }

    public static function migrate(BufferedOutput $outputLog)
    {
        try {
            Artisan::call('migrate', ['--force' => true], $outputLog);
        } catch (Exception $e) {
            return self::response($e->getMessage(), 'error', $outputLog);
        }
        return self::seed($outputLog);
    }

    public static function seed(BufferedOutput $outputLog)
    {
        try {
            Artisan::call('db:seed', ['--force' => true], $outputLog);
        } catch (Exception $e) {
            return self::response($e->getMessage(), 'error', $outputLog);
        }
        return self::response(__('installer_messages.final.finished'), 'success', $outputLog);
    }

    public static function response($message, $status, BufferedOutput $outputLog)
    {
        return [
            'status' => $status,
            'message' => $message,
            'dbOutputLog' => $outputLog->fetch(),
        ];
    }

    public static function sqlite(BufferedOutput $outputLog)
    {
        if (DB::connection() instanceof SQLiteConnection) {
            $database = DB::connection()->getDatabaseName();
            if (!file_exists($database)) {
                touch($database);
                DB::reconnect(Config::get('database.default'));
            }
            $outputLog->write('Using SqlLite database: ' . $database, 1);
        }
    }

    /*********
     *  Requirements management
     */
    private static $minPhpVersion = '8.1.6';

    public static function checkRequirements(array $requirements)
    {
        $results = [];

        foreach ($requirements as $type => $requirement) {
            switch ($type) {
                    // check php requirements
                case 'php':
                    foreach ($requirements[$type] as $requirement) {
                        $results['requirements'][$type][$requirement] = true;

                        if (!extension_loaded($requirement)) {
                            $results['requirements'][$type][$requirement] = false;

                            $results['errors'] = true;
                        }
                    }
                    break;
                    // check apache requirements
                case 'apache':
                    foreach ($requirements[$type] as $requirement) {
                        // if function doesn't exist we can't check apache modules
                        if (function_exists('apache_get_modules')) {
                            $results['requirements'][$type][$requirement] = true;

                            if (!in_array($requirement, apache_get_modules())) {
                                $results['requirements'][$type][$requirement] = false;

                                $results['errors'] = true;
                            }
                        }
                    }
                    break;
            }
        }

        return $results;
    }

    public static function checkPHPversion(string $minPhpVersion = null)
    {
        $minVersionPhp = $minPhpVersion;
        $currentPhpVersion = self::getPhpVersionInfo();
        $supported = false;

        if ($minPhpVersion == null) {
            $minVersionPhp = self::getMinPhpVersion();
        }

        if (version_compare($currentPhpVersion['version'], $minVersionPhp) >= 0) {
            $supported = true;
        }

        $phpStatus = [
            'full' => $currentPhpVersion['full'],
            'current' => $currentPhpVersion['version'],
            'minimum' => $minVersionPhp,
            'supported' => $supported,
        ];

        return $phpStatus;
    }

    private static function getPhpVersionInfo()
    {
        $currentVersionFull = PHP_VERSION;
        preg_match("#^\d+(\.\d+)*#", $currentVersionFull, $filtered);
        $currentVersion = $filtered[0];

        return [
            'full' => $currentVersionFull,
            'version' => $currentVersion,
        ];
    }

    protected static function getMinPhpVersion()
    {
        return self::$minPhpVersion;
    }


    /************
     *  Permission management
     */

    public static $permission_results = [];

    public static function checkPermissions(array $folders)
    {
        foreach ($folders as $folder => $permission) {
            if (!(self::getPermission($folder) >= $permission)) {
                self::addFileAndSetErrors($folder, $permission, false);
            } else {
                self::addFile($folder, $permission, true);
            }
        }

        return self::$permission_results;
    }

    private static function getPermission($folder)
    {
        return substr(sprintf('%o', fileperms(base_path($folder))), -4);
    }

    private static function addFile($folder, $permission, $isSet)
    {
        self::$permission_results['permissions'][] = [
            'folder' => $folder,
            'permission' => $permission,
            'isSet' => $isSet
        ];
        // dd(self::$permission_results);

        // array_push(self::$permission_results['permissions'], [
        //     'folder' => $folder,
        //     'permission' => $permission,
        //     'isSet' => $isSet
        // ]);
    }

    private static function addFileAndSetErrors($folder, $permission, $isSet)
    {
        self::addFile($folder, $permission, $isSet);
        self::$permission_results['errors'] = true;
    }

    /***************
     *  Finalization
     */

    public static function create()
    {
        $installedLogFile = storage_path('installed');
        $dateStamp = date('Y/m/d h:i:sa');
        if (!file_exists($installedLogFile)) {
            $message = __('installer_messages.installed.success_log_message') . $dateStamp . "\n";

            file_put_contents($installedLogFile, $message);
        } else {
            $message = __('installer_messages.updater.log.success_message') . $dateStamp;

            file_put_contents($installedLogFile, $message . PHP_EOL, FILE_APPEND | LOCK_EX);
        }

        return $message;
    }

    public static function update()
    {
        return self::create();
    }

    public static function runFinal()
    {
        $outputLog = new BufferedOutput;

        self::generateKey($outputLog);
        self::publishVendorAssets($outputLog);

        return $outputLog->fetch();
    }

    private static function generateKey(BufferedOutput $outputLog)
    {
        try {
            if (config('installer.final.key')) {
                Artisan::call('key:generate', ['--force' => true], $outputLog);
            }
        } catch (Exception $e) {
            return static::getResponse($e->getMessage(), $outputLog);
        }

        return $outputLog;
    }

    private static function publishVendorAssets(BufferedOutput $outputLog)
    {
        try {
            if (config('installer.final.publish')) {
                Artisan::call('vendor:publish', ['--all' => true], $outputLog);
            }
        } catch (Exception $e) {
            return static::getResponse($e->getMessage(), $outputLog);
        }

        return $outputLog;
    }

    private static function getResponse($message, BufferedOutput $outputLog)
    {
        return [
            'status' => 'error',
            'message' => $message,
            'dbOutputLog' => $outputLog->fetch(),
        ];
    }

    public static function isActive($route, $className = 'active')
    {
        if (is_array($route)) {
            return in_array(Route::currentRouteName(), $route) ? $className : '';
        }
        if (Route::currentRouteName() == $route) {
            return $className;
        }
        if (strpos(URL::current(), $route)) {
            return $className;
        }
    }
}
