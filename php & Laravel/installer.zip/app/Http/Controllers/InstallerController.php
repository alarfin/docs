<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Installer\Installer;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\Validator;

class InstallerController extends Controller
{
    public function welcome()
    {
        return view('installer.welcome');
        $data = Installer::getEnvContent();
    }

    public function environmentMenu()
    {
        return view('installer.environment');
    }

    public function environmentWizard()
    {
        $envConfig = Installer::getEnvContent();
        return view('installer.environment-wizard', compact('envConfig'));
    }

    public function saveWizard(Request $request, Redirector $redirect)
    {
        $rules = config('installer.environment.form.rules');
        $messages = [
            'environment_custom.required_if' => __('installer_messages.environment.wizard.form.name_required'),
        ];

        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return $redirect->route('install_environmentWizard')->withInput()->withErrors($validator->errors());
        }

        if (!Installer::checkDatabaseConnection($request)) {
            return $redirect->route('install_environmentWizard')->withInput()->withErrors([
                'database_connection' => __('installer_messages.environment.wizard.form.db_connection_failed'),
            ]);
        }
        $results = Installer::saveFileWizard($request);

        return $redirect->route('install_database')
            ->with(['results' => $results]);
    }

    public function environmentClassic()
    {
        $envConfig = Installer::getEnvContent();
        return view('installer.environment-classic', compact('envConfig'));
    }

    public function database()
    {
        $response = Installer::migrateAndSeed();

        return redirect()->route('install_final')
            ->with(['message' => $response]);
    }

    public function requirements()
    {
        $phpSupportInfo = Installer::checkPHPversion(
            config('installer.core.minPhpVersion')
        );
        $requirements = Installer::checkRequirements(
            config('installer.requirements')
        );

        return view('installer.requirements', compact('requirements', 'phpSupportInfo'));
    }

    public function permissions()
    {
        $permissions = Installer::checkPermissions(
            config('installer.permissions')
        );

        return view('installer.permissions', compact('permissions'));
    }

    public function finish()
    {
        $finalMessages = Installer::runFinal();
        $finalStatusMessage = Installer::update();
        $finalEnvFile = Installer::getEnvContent();

        // event(new LaravelInstallerFinished);

        return view('installer.finished', compact('finalMessages', 'finalStatusMessage', 'finalEnvFile'));
    }
}
