<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Route;

Route::group(['prefix' => 'install', 'as' => 'install_'], function () {
    Route::get('/', [InstallerController::class, 'welcome'])->name('welcome');
    Route::get('/environment', [InstallerController::class, 'environmentMenu'])->name('environment');
    Route::get('environment/wizard', [InstallerController::class, 'environmentWizard'])->name('environmentWizard');
    Route::post('environment/saveWizard', [InstallerController::class, 'saveWizard'])->name('environmentSaveWizard');
    Route::get('environment/classic', [InstallerController::class, 'environmentClassic'])->name('environmentClassic');
    Route::post('environment/saveClassic', [InstallerController::class, 'saveClassic'])->name('environmentSaveClassic');
    Route::get('requirements', [InstallerController::class, 'requirements'])->name('requirements');
    Route::get('permissions', [InstallerController::class, 'permissions'])->name('permissions');
    Route::get('database', [InstallerController::class, 'database'])->name('database');
    Route::get('final', [InstallerController::class, 'finish'])->name('final');
});
