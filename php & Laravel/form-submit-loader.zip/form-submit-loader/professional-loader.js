/**
 * ==========================================
 * Premium Loader Plugin
 * ==========================================
 *
 * USAGE:
 *
 * PremiumLoader.show();
 *
 * PremiumLoader.show(
 *     'Uploading Files',
 *     'Please wait while we upload your files...'
 * );
 *
 * PremiumLoader.hide();
 *
 * ==========================================
 */

window.PremiumLoader = (function () {

    let loader = null;

    /**
     * Create Loader HTML + CSS Automatically
     */
    function init() {

        if (document.getElementById('premiumLoader')) {
            loader = document.getElementById('premiumLoader');
            return;
        }

        /**
         * Inject CSS
         */
        const style = document.createElement('style');

        style.innerHTML = `
        
        .premium-loader-overlay{
            position: fixed;
            inset: 0;
            z-index: 999999;

            display: flex;
            align-items: center;
            justify-content: center;

            background:
                radial-gradient(circle at top right, rgba(58, 55, 212, 0.10), transparent 55%),
                radial-gradient(circle at bottom left, rgba(123, 81, 201, 0.03), transparent 55%),
                rgba(0, 0, 0, 0.38);

            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);

            animation: premiumFade .3s ease;
        }

        .premium-loader-box{
            width:430px;
            max-width:92%;
            padding:45px 35px;
            border-radius:30px;
            background:rgba(73, 71, 82, 0.08);
            border:1px solid rgba(255,255,255,.1);
            backdrop-filter:blur(20px);
            text-align:center;
            color:#fff;
            box-shadow:
                0 25px 80px rgba(0,0,0,.45),
                inset 0 1px 1px rgba(255,255,255,.05);

            overflow:hidden;
            position:relative;
        }

        .premium-loader-box::before{
            content:'';
            position:absolute;
            inset:0;

            background:linear-gradient(
                120deg,
                transparent,
                rgba(255,255,255,.05),
                transparent
            );

            transform:translateX(-100%);
            animation:shine 3s linear infinite;
        }

        .premium-spinner-wrap{
            width:120px;
            height:120px;
            margin:auto;
            position:relative;
        }

        .premium-spinner-ring{
            position:absolute;
            inset:0;
            border-radius:50%;
            border:5px solid rgba(255,255,255,.08);
            border-top:5px solid #d4af37;
            border-right:5px solid #f5d76e;
            animation:spin 1s linear infinite;
        }

        .premium-spinner-core{
            width:78px;
            height:78px;
            border-radius:50%;
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%, -50%);
            display:flex;
            align-items:center;
            justify-content:center;
            background:linear-gradient(
                135deg,
                #d4af37,
                #f5d76e
            );

            box-shadow:
                0 10px 30px rgba(212,175,55,.4);
            font-size:30px;
            color:#111;
            animation:pulse 1.8s ease infinite;
        }

        .premium-loader-box h3{
            margin-top:28px;
            font-size:28px;
            font-weight:700;
        }

        .premium-loader-box p{
            margin-top:12px;
            color:#d9d9d9;
            line-height:1.8;
            font-size:15px;
        }

        .premium-progress{
            height:8px;
            margin-top:28px;
            background:rgba(255,255,255,.08);
            border-radius:999px;
            overflow:hidden;
        }

        .premium-progress-bar{
            height:100%;
            width:40%;
            border-radius:999px;
            background:linear-gradient(
                90deg,
                #d4af37,
                #f5d76e,
                #d4af37
            );

            animation:loadingBar 1.5s infinite ease;
        }

        @keyframes spin{
            to{
                transform:rotate(360deg);
            }
        }

        @keyframes pulse{
            0%{
                transform:translate(-50%, -50%) scale(1);
            }

            50%{
                transform:translate(-50%, -50%) scale(1.08);
            }

            100%{
                transform:translate(-50%, -50%) scale(1);
            }
        }

        @keyframes loadingBar{
            0%{
                margin-left:-40%;
            }

            100%{
                margin-left:100%;
            }
        }

        @keyframes premiumFade{
            from{
                opacity:0;
            }

            to{
                opacity:1;
            }
        }

        @keyframes shine{
            100%{
                transform:translateX(100%);
            }
        }

        `;

        document.head.appendChild(style);

        /**
         * Inject HTML
         */
        loader = document.createElement('div');

        loader.id = 'premiumLoader';

        loader.className = 'premium-loader-overlay';

        loader.style.display = 'none';

        loader.innerHTML = `
        
        <div class="premium-loader-box">
        
            <div class="premium-spinner-wrap">
                <div class="premium-spinner-ring"></div>
                <div class="premium-spinner-core">
                    <i class="fa-solid fa-rocket fa-bounce"></i>
                </div>
            </div>

            <h3>
                Processing Your Submission
            </h3>

            <p>
                Please wait while we process your request securely.
            </p>

            <div class="premium-progress">
                <div class="premium-progress-bar"></div>
            </div>

        </div>

        `;

        document.body.appendChild(loader);
    }

    /**
     * Show Loader
     */
    function show(title, text) {

        init();

        const titleEl = loader.querySelector('h3');
        const textEl = loader.querySelector('p');

        titleEl.innerText =
            title || 'Processing Your Submission';

        textEl.innerText =
            text || 'Please wait while we process your request securely.';

        loader.style.display = 'flex';

        document.body.style.overflow = 'hidden';
    }

    /**
     * Hide Loader
     */
    function hide() {

        if (!loader) return;

        loader.style.display = 'none';

        document.body.style.overflow = '';
    }

    /**
     * Public Methods
     */
    return {
        show,
        hide
    };

})();