<?php

namespace App\Http\Controllers;

use App\Models\Package;
use App\Models\User;
use App\Library\SslCommerz\SslCommerzNotification;
use App\Models\Invoice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PaymentController extends Controller
{
    public function packagePayment($user_id)
    {
        $user = User::find($user_id);
        $package = Package::find($user->package_id);
        if ($package) {
            $post_data = array();
            $post_data['total_amount'] = $package->price; # You cant not pay less than 10
            $post_data['currency'] = "BDT";
            $post_data['tran_id'] = "package-" . $package->id; // tran_id must be unique

            # CUSTOMER INFORMATION
            $post_data['cus_name'] = $user->name;
            $post_data['cus_email'] = $user->email;
            $post_data['cus_add1'] = $user->address ?? 'Unknown address';
            $post_data['cus_add2'] = "";
            $post_data['cus_city'] = "";
            $post_data['cus_state'] = "";
            $post_data['cus_postcode'] = "";
            $post_data['cus_country'] = $user->country->name ?? "Bangladesh";
            $post_data['cus_phone'] = $user->country->phone_code ?? "880" . $user->phone ?? "";
            $post_data['cus_fax'] = "";

            # SHIPMENT INFORMATION
            // $post_data['ship_name'] = "Store Test";
            // $post_data['ship_add1'] = "Dhaka";
            // $post_data['ship_add2'] = "Dhaka";
            // $post_data['ship_city'] = "Dhaka";
            // $post_data['ship_state'] = "Dhaka";
            // $post_data['ship_postcode'] = "1000";
            // $post_data['ship_phone'] = "";
            // $post_data['ship_country'] = "Bangladesh";

            $post_data['shipping_method'] = "NO";
            $post_data['product_name'] = $package->name;
            $post_data['product_category'] = $package->name;
            $post_data['product_profile'] = $package->name;

            # OPTIONAL PARAMETERS
            $post_data['value_a'] = "package_payment";
            $post_data['value_b'] = "";
            $post_data['value_c'] = "";
            $post_data['value_d'] = "";

            // Invoice update
            $invoice = Invoice::where('user_id', $user->id)->where('package_id', $package->id)->latest()->first();
            $invoice->tran_id = $post_data['tran_id'];
            $invoice->currency = $post_data['currency'];
            $invoice->save();

            $sslc = new SslCommerzNotification();
            $payment_options = $sslc->makePayment($post_data, 'hosted');

            if (!is_array($payment_options)) {
                print_r($payment_options);
                $payment_options = array();
            }
        }
        return false;
    }

    public function success(Request $request)
    {
        $tran_id = $request->input('tran_id');
        $amount = $request->input('amount');
        $sslc = new SslCommerzNotification();
        $invoice = Invoice::where('tran_id', $tran_id)->first();
        $user = User::find($invoice->user_id);
        Auth::login($user);
        if ($invoice->status == 0) {
            $invoice->paid = $amount;
            $invoice->due = $invoice->total - $invoice->paid;
            $invoice->status = 1;
            $invoice->save();
            $data = [
                'success' => true,
                'title' => __('general.paid'),
                'message' => __('general.you_have_successfully_paid'),
                'btn_text' => __('general.go_to_dashboard'),
                'btn_link' => route('home'),
                'invoice' => $invoice,
            ];
            return view('frontend.pages.extra-page.payment_message', compact('data'));
        } else {
            $data = [
                'success' => true,
                'title' => __('general.paid'),
                'message' => __('general.you_have_successfully_paid'),
                'btn_text' => __('general.go_to_dashboard'),
                'btn_link' => route('home'),
                'invoice' => $invoice,
            ];
            return view('frontend.pages.extra-page.payment_message', compact('data'));
        }
    }

    public function fail(Request $request)
    {
        $tran_id = $request->input('tran_id');
        $invoice = Invoice::where('tran_id', $tran_id)->first();
        if ($invoice->status == 0) {
            $data = [
                'success' => false,
                'title' => __('general.failed'),
                'message' => __('general.payment_failed'),
                'btn_text' => __('general.go_to_login'),
                'btn_link' => url('login'),
                'invoice' => $invoice,
            ];
            return view('frontend.pages.extra-page.payment_message', compact('data'));
        } else {
            $data = [
                'success' => false,
                'title' => __('general.failed'),
                'message' => __('general.already_paid'),
                'btn_text' => __('general.go_to_login'),
                'btn_link' => url('login'),
                'invoice' => $invoice,
            ];
            return view('frontend.pages.extra-page.payment_message', compact('data'));
        }
    }

    public function cancel(Request $request)
    {
        $tran_id = $request->input('tran_id');
        $invoice = Invoice::where('tran_id', $tran_id)->first();
        $data = [
            'success' => false,
            'title' => __('general.failed'),
            'message' => __('general.cancel_payment'),
            'btn_text' => __('general.go_to_login'),
            'btn_link' => url('login'),
            'invoice' => $invoice,
        ];
        return view('frontend.pages.extra-page.payment_message', compact('data'));
    }

    public function ipn(Request $request)
    {
        if ($request->input('tran_id')) 
        {
            $tran_id = $request->input('tran_id');
            $amount = $request->input('amount');
            $invoice = Invoice::where('tran_id', $tran_id)->first();

            if ($invoice->status == 0) {
                $invoice->paid = $amount;
                $invoice->due = ($invoice->total - $invoice->paid);
                $invoice->status = 1;
                $invoice->save();
                $data = [
                    'success' => true,
                    'title' => __('general.paid'),
                    'message' => __('general.you_have_successfully_paid'),
                    'btn_text' => __('general.go_to_dashboard'),
                    'btn_link' => route('home'),
                    'invoice' => $invoice,
                ];
                return view('frontend.pages.extra-page.payment_message', compact('data'));
            } else {
                $data = [
                    'success' => true,
                    'title' => __('general.paid'),
                    'message' => __('general.you_have_successfully_paid'),
                    'btn_text' => __('general.go_to_dashboard'),
                    'btn_link' => route('home'),
                    'invoice' => $invoice,
                ];
                return view('frontend.pages.extra-page.payment_message', compact('data'));
            }
        } else {
            $data = [
                'success' => false,
                'title' => __('general.failed'),
                'message' => __('general.already_paid'),
                'btn_text' => __('general.go_to_login'),
                'btn_link' => url('login'),
                'invoice' => [],
            ];
            return view('frontend.pages.extra-page.payment_message', compact('data'));
        }
    }
}
