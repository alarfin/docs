<?php

use App\Http\Controllers\SslCommerzPaymentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Payment routes
Route::get('package-payment/{user_id}', [PaymentController::class, 'packagePayment'])->name('package.payment');
Route::get('payment-message/{data}', [PaymentController::class, 'paymentMessage'])->name('payment.message');
Route::post('/success', [PaymentController::class, 'success'])->name('payment.success');
Route::post('/fail', [PaymentController::class, 'fail'])->name('payment.fail');
Route::post('/cancel', [PaymentController::class, 'cancel'])->name('payment.cancel');
Route::post('/ipn', [PaymentController::class, 'ipn'])->name('payment.ipn');
